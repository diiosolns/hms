@extends('layouts.app')

@section('content')
    {{-- Place the HTML code here --}}
@endsection