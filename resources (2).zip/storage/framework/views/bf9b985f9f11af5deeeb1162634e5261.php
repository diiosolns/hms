<?php $__env->startSection('content'); ?>
    <div class="nk-content">
        <div class="container">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    <?php if($invoice): ?>
                        <div class="nk-block-head">
                            <div class="nk-block-head-between flex-wrap gap g-2 align-items-start">
                                <div class="nk-block-head-content">
                                    <div class="d-flex flex-column flex-md-row align-items-md-center">
                                        <a href="<?php echo e(route('patients.show', $invoice->patient->id)); ?>">
                                            <div class="media media-huge media-middle media-circle text-bg-primary-soft">
                                                <span class="huge"><?php echo e(strtoupper(substr($invoice->invoice_number, 0, 3))); ?></span>
                                            </div>
                                        </a>
                                        <div class="mt-3 mt-md-0 ms-md-3">
                                            <h3 class="title mb-1"><?php echo e($invoice->patient->first_name); ?> <?php echo e($invoice->patient->last_name); ?></h3>
                                            <span class="badge bg-primary">Invoice No.: <?php echo e($invoice->invoice_number); ?></span>
                                            <ul class="nk-list-option pt-1">
                                                <?php if($invoice->patient->branch): ?>
                                                    <li><em class="icon ni ni-building"></em>
                                                        <span class="small"><?php echo e($invoice->patient->phone); ?></span>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="nk-block-head-content">
                                    <div class="d-flex gap g-3">
                                        <div class="gap-col">
                                            <div class="box-dotted py-2">
                                                <div class="d-flex align-items-center">
                                                    <?php if($invoice->status === 'Paid'): ?>
                                                        <div class="h1 mb-0 text-success"><span class="small">TZS</span> <?php echo e(number_format($invoice->total_amount, 0)); ?></div>
                                                    <?php else: ?>
                                                        <div class="h1 mb-0 text-danger"><span class="small">TZS</span> <?php echo e(number_format($invoice->total_amount, 0)); ?></div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="smaller mt-3">Date: <?php echo e($invoice->invoice_date ? \Carbon\Carbon::parse($invoice->invoice_date)->format('M d, Y') : 'N/A'); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="nk-block-head-between gap g-2 mt-4">
                                <div class="gap-col"></div>
                                <div class="gap-col">
                                    <ul class="d-flex gap g-2">
                                        
                                        <?php if(in_array(Auth::user()->role, ['receptionist', 'admin']) && $invoice->status !== 'Paid'): ?>
                                            <li class="d-none d-md-block">
                                                <form action="<?php echo e(route('invoices.clearBill', $invoice->id)); ?>" 
                                                      method="POST" onsubmit="return confirm('Are you sure you want to clear this bill?')">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-soft btn-primary">
                                                        <em class="icon ni ni-check"></em> Clear Bill
                                                    </button>
                                                </form>
                                            </li>
                                        <?php endif; ?>

                                        
                                        <?php if(
                                            (Auth::user()->role === 'receptionist' && $invoice->status !== 'Paid') || 
                                            (Auth::user()->role === 'admin')
                                        ): ?>
                                            <li class="d-none d-md-block">
                                                <form action="<?php echo e(route('invoices.cancel', $invoice->id)); ?>" 
                                                      method="POST" onsubmit="return confirm('Are you sure you want to cancel this invoice?')">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-soft btn-danger">
                                                        <em class="icon ni ni-cross"></em> Cancel
                                                    </button>
                                                </form>
                                            </li>
                                        <?php endif; ?>

                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="nk-block">
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane show active" id="tab-1" tabindex="0" role="tabpanel">
                                    <div class="card h-100 mt-4">
                                        <div class="card-body flex-grow-0 py-2">
                                            <div class="card-title-group">
                                                <div class="card-title">
                                                    <h4 class="title">Invoices Items</h4>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="table-responsive">
                                            <table class="table table-middle mb-0">
                                                <thead class="table-light table-head-md">
                                                    <tr>
                                                        <th class="tb-col"><span class="overline-title">S/N</span></th>
                                                        <th class="tb-col"><span class="overline-title">Description</span></th>
                                                        <th class="tb-col tb-col-end tb-col-sm"><span class="overline-title">Qnty</span></th>
                                                        <th class="tb-col tb-col-end tb-col-sm"><span class="overline-title">Unit Price (TZS)</span></th>
                                                        <th class="tb-col tb-col-end tb-col-sm"><span class="overline-title">Total Amount (TZS)</span></th>
                                                        <th class="tb-col tb-col-end"><span class="overline-title">Actions</span></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__empty_1 = true; $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <tr>
                                                            <td class="tb-col">
                                                                <span class="small"><?php echo e($key + 1); ?></span>
                                                            </td>
                                                            <td class="tb-col">
                                                                <span class="small"><?php echo e($inv->description ?? 'N/A'); ?></span>
                                                            </td>
                                                            <td class="tb-col tb-col-end tb-col-sm">
                                                                <span class="small"><?php echo e(number_format($inv->quantity, 0)); ?></span>
                                                            </td>
                                                            <td class="tb-col tb-col-end tb-col-sm">
                                                                <span class="small"><?php echo e(number_format($inv->unit_price, 0)); ?></span>
                                                            </td>
                                                            <td class="tb-col tb-col-end tb-col-sm">
                                                                <span class="small"><?php echo e(number_format($inv->total, 0)); ?></span>
                                                            </td>
                                                            <td class="tb-col tb-col-end">
                                                                
                                                                <?php if($invoice->status !== 'Paid' && in_array(Auth::user()->role, ['receptionist', 'admin', 'doctor'])): ?>
                                                                    <form action="<?php echo e(route('invoices.removeItem', [$invoice->id, $inv->id])); ?>" 
                                                                          method="POST" onsubmit="return confirm('Are you sure you want to remove this item?')">
                                                                        <?php echo csrf_field(); ?>
                                                                        <?php echo method_field('DELETE'); ?>
                                                                        <button type="submit" class="btn btn-sm btn-outline-danger">Remove</button>
                                                                    </form>
                                                                <?php elseif($invoice->status === 'Paid'): ?>
                                                                    <span class="badge bg-success">PAID</span>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <tr>
                                                            <td colspan="6" class="text-center text-muted">No invoice items found.</td>
                                                        </tr>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>

                                        <div class="card-footer text-center text-primary">
                                            Make sure all bills are cleared before going to next step.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-danger" role="alert">
                            Invoice not found.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/patients/invoice.blade.php ENDPATH**/ ?>