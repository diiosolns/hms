<?php $__env->startSection('content'); ?>
<div class="text-center p-10">
    <h1 class="text-4xl font-bold text-red-600">429</h1>
    <p class="text-lg mt-4">Too many requests. Please slow down.</p>
    <a href="<?php echo e(route('login')); ?>">Login</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/errors/419.blade.php ENDPATH**/ ?>