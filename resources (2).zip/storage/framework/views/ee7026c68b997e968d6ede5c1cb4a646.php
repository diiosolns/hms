<?php $__env->startSection('content'); ?>
    
    <!-- content -->
    <div class="nk-content">
        <div class="container-fluid">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    <div class="row g-gs">
                        <div class="col-xxl-7">
                            
                            <div class="row g-gs ">
                                
                                <div class="col-md-12">
                                    <a href="<?php echo e(route('admin.employees.manage')); ?>">
                                    <div class="card h-100">
                                        <div class="card-body">
                                            <div class="d-flex flex-column flex-sm-row-reverse align-items-sm-center justify-content-sm-between gx-xl-5">
                                                <div class="nk-chart-project-earnings">
                                                    <canvas data-nk-chart="line" id="employeesChart"></canvas>
                                                </div>
                                                <div class="card-title mb-0 mt-4 mt-sm-0">
                                                    <h5 class="title mb-3 mb-xl-5">Users</h5>
                                                    <div class="amount h1"><?php echo e($totalUsers); ?></div>
                                                    <div class="d-flex align-items-center smaller flex-wrap">
                                                        <div class="change up">
                                                            <em class="icon ni ni-user-list-fill"></em>
                                                        </div>
                                                        <span class="text-light badge text-bg-primary-soft m-1"><?php echo e($receptionists); ?> Receptionists </span>
                                                        <span class="text-light badge text-bg-primary-soft m-1"><?php echo e($nurses); ?> Nurses </span>
                                                        <span class="text-light badge text-bg-primary-soft m-1"><?php echo e($doctors); ?> Doctors </span>
                                                        <span class="text-light badge text-bg-primary-soft m-1"><?php echo e($pharmacists); ?> Pharmacists </span>
                                                        <span class="text-light badge text-bg-primary-soft m-1"><?php echo e($lab_tchnicians); ?> Lab Technicians </span>
                                                    </div>
                                                </div>
                                            </div><!-- .row -->
                                        </div><!-- .card-body -->
                                    </div><!-- .card -->
                                    </a>
                                </div><!-- .col -->

                                
                                <div class="col-md-6">
                                    <a href="<?php echo e(route('admin.employees.manage')); ?>">
                                    <div class="card h-100">
                                        <div class="card-body">
                                            <div class="d-flex flex-column flex-sm-row-reverse align-items-sm-center justify-content-sm-between gx-xl-5">
                                                <div class="nk-chart-project-done js-pureknob" data-readonly="true" data-size="136" data-angle-offset="-.5" data-angle-start=".7" data-angle-end=".7" data-value="<?php echo e($totalPatients > 0 ? round(100 * ($malePatients / $totalPatients), 2) : 0); ?>" data-color-fg="#F24A8B" data-track-width="0.15">
                                                    <span class="knob-title small text-light">Male</span>
                                                </div>
                                                <div class="card-title mb-0 mt-4 mt-sm-0">
                                                    <h5 class="title mb-3 mb-xl-5">Patients</h5>
                                                    <div class="amount h1"><?php echo e($totalPatients); ?></div>
                                                    <div class="d-flex align-items-center smaller flex-wrap">
                                                        <div class="change up">
                                                            <em class="icon ni ni-user-fill"></em>
                                                        </div>
                                                        <span class="text-light badge text-bg-primary-soft m-1"><?php echo e($malePatients); ?> Male</span>
                                                        <span class="text-light badge text-bg-primary-soft m-1"><?php echo e($femalePatients); ?> Female</span>
                                                    </div>
                                                </div>
                                            </div><!-- .row -->
                                        </div><!-- .card-body -->
                                    </div><!-- .card -->
                                    </a>
                                </div><!-- .col -->

                                
                                <div class="col-md-6">
                                    <a href="<?php echo e(route('admin.appointments.index')); ?>">
                                    <div class="card h-100">
                                        <div class="card-body">
                                            <div class="d-flex flex-column flex-sm-row-reverse align-items-sm-center justify-content-sm-between gx-xl-5">
                                                <div class="nk-chart-project-done js-pureknob" data-readonly="true" data-size="136" data-angle-offset="-.5" data-angle-start=".7" data-angle-end=".7" data-value="<?php echo e($scheduledAppointments > 0 ? round(100 * ($maleAppointments / $scheduledAppointments), 2) : 0); ?>" data-color-fg="#F24A8B" data-track-width="0.15">
                                                    <span class="knob-title small text-light">Male</span>
                                                </div>
                                                <div class="card-title mb-0 mt-4 mt-sm-0">
                                                    <h5 class="title mb-3 mb-xl-5">Appointments</h5>
                                                    <div class="amount h1"><?php echo e($scheduledAppointments); ?></div>
                                                    <div class="d-flex align-items-center smaller flex-wrap">
                                                        <div class="change up">
                                                            <em class="icon ni ni-user-fill"></em>
                                                        </div>
                                                        <span class="text-light badge text-bg-primary-soft m-1"><?php echo e($maleAppointments); ?> Male</span>
                                                        <span class="text-light badge text-bg-primary-soft m-1"><?php echo e($femaleAppointments); ?> Female</span>
                                                    </div>
                                                </div>
                                            </div><!-- .row -->
                                        </div><!-- .card-body -->
                                    </div><!-- .card -->
                                    </a>
                                </div><!-- .col -->
                            </div><!-- .row -->



                            <div class="row g-gs mt-2">
                                
                                <div class="col-md-6">
                                    <a href="<?php echo e(route('admin.employees.manage')); ?>">
                                    <div class="card h-100">
                                        <div class="card-body">
                                            <div class="d-flex flex-column flex-sm-row-reverse align-items-sm-center justify-content-sm-between">
                                                <div class="nk-chart-project-active js-pureknob" data-readonly="true" data-size="110" data-angle-offset="0.4" data-angle-start="1" data-angle-end="1" data-value="<?php echo e(($paidCashInvoices+$paidNonCashInvoices) > 0 ? round(100 * ($paidCashInvoices / ($paidCashInvoices+$paidNonCashInvoices)), 2) : 0); ?>" data-track-width="0.15"></div>
                                                <div class="card-title mb-0 mt-4 mt-sm-0">
                                                    <h5 class="title mb-3 mb-xl-5">Total Ammount</h5>
                                                    <div class="amount h1 text-success"><?php echo e(number_format($paidCashInvoices + $paidNonCashInvoices, 0)); ?> <small> TZS</small></div>
                                                    <div class="d-flex align-items-center smaller flex-wrap">
                                                        <div class="change up">
                                                            <em class="icon ni ni-hospital-fill"></em>
                                                        </div>
                                                        <span class="text-light badge text-bg-success-soft m-1">Cash: <?php echo e(number_format($paidCashInvoices, 0)); ?>/=</span>
                                                        <span class="text-light badge text-bg-success-soft m-1">Other: <?php echo e(number_format($paidNonCashInvoices, 0)); ?>/=</span>
                                                    </div>
                                                </div>
                                            </div><!-- .row -->
                                        </div><!-- .card-body -->
                                    </div><!-- .card -->
                                    </a>
                                </div><!-- .col -->

                                
                                <div class="col-md-6">
                                    <a href="<?php echo e(route('admin.employees.manage')); ?>">
                                    <div class="card h-100">
                                        <div class="card-body">
                                            <div class="d-flex flex-column flex-sm-row-reverse align-items-sm-center justify-content-sm-between gx-xl-5">
                                                <div class="nk-chart-project-done js-pureknob" data-readonly="true" data-size="136" data-angle-offset="-.5" data-angle-start=".7" data-angle-end=".7" data-value="<?php echo e(($pendingCashInvoices+$pendingNonCashInvoices) > 0 ? round(100 * ($pendingCashInvoices / ($pendingCashInvoices+$pendingNonCashInvoices)), 2) : 0); ?>" data-track-width="0.15">
                                                    <span class="knob-title small text-light">Cash</span>
                                                </div>
                                                <div class="card-title mb-0 mt-4 mt-sm-0">
                                                    <h5 class="title mb-3 mb-xl-5">Pendning Invoices</h5>
                                                    <div class="amount h1 text-danger"><?php echo e(number_format($pendingCashInvoices + $pendingNonCashInvoices, 0)); ?> <small> TZS</small></div>
                                                    <div class="d-flex align-items-center smaller flex-wrap">
                                                        <div class="change up">
                                                            <em class="icon ni ni-hospital-fill"></em>
                                                        </div>
                                                        <span class="text-light badge text-bg-danger-soft m-1">Cash: <?php echo e(number_format($pendingCashInvoices, 0)); ?></span>
                                                        <span class="text-light badge text-bg-danger-soft m-1">Other: <?php echo e(number_format($pendingNonCashInvoices, 0)); ?></span>
                                                    </div>
                                                </div>
                                            </div><!-- .row -->
                                        </div><!-- .card-body -->
                                    </div><!-- .card -->
                                    </a>
                                </div><!-- .col -->
                            </div><!-- .row -->

                            

                            <div class="row g-gs mt-2">
                                
                                <div class="col-md-6">
                                    <a href="<?php echo e(route('admin.employees.manage')); ?>">
                                    <div class="card h-100">
                                        <div class="card-body">
                                            <div class="d-flex flex-column flex-sm-row-reverse align-items-sm-center justify-content-sm-between">
                                                <div class="nk-chart-project-active js-pureknob" data-readonly="true" data-size="110" data-angle-offset="0.4" data-angle-start="1" data-angle-end="1" data-value="<?php echo e($totalPatients > 0 ? round(100 * ($malePatients / $totalPatients), 2) : 0); ?>" data-track-width="0.15"></div>
                                                <div class="card-title mb-0 mt-4 mt-sm-0">
                                                    <h5 class="title mb-3 mb-xl-5">Laboratory</h5>
                                                    <div class="amount h1"><?php echo e($totalPatients); ?></div>
                                                    <div class="d-flex align-items-center smaller flex-wrap">
                                                        <div class="change up">
                                                            <em class="icon ni ni-hospital-fill"></em>
                                                        </div>
                                                        <span class="text-light">Laboratory tests</span>
                                                    </div>
                                                </div>
                                            </div><!-- .row -->
                                        </div><!-- .card-body -->
                                    </div><!-- .card -->
                                    </a>
                                </div><!-- .col -->

                                
                                <div class="col-md-6">
                                    <a href="<?php echo e(route('admin.employees.manage')); ?>">
                                    <div class="card h-100">
                                        <div class="card-body">
                                            <div class="d-flex flex-column flex-sm-row-reverse align-items-sm-center justify-content-sm-between gx-xl-5">
                                                <div class="nk-chart-project-earnings">
                                                    <canvas data-nk-chart="bar" id="branchesChart"></canvas>
                                                </div>
                                                <div class="card-title mb-0 mt-4 mt-sm-0">
                                                    <h5 class="title mb-3 mb-xl-5">Pharmacy</h5>
                                                    <div class="amount h1"><?php echo e($totalPatients); ?></div>
                                                    <div class="d-flex align-items-center smaller flex-wrap">
                                                        <div class="change up">
                                                            <em class="icon ni ni-plus-circle-fill"></em>
                                                        </div>
                                                        <span class="text-light">Pharmacy Catalogy</span>
                                                    </div>
                                                </div>
                                            </div><!-- .row -->
                                        </div><!-- .card-body -->
                                    </div><!-- .card -->
                                    </a>
                                </div><!-- .col -->
                            </div><!-- .row -->
                        </div><!-- .col -->
                    </div><!-- .row -->




                    



                        </div><!-- .col -->
                    </div><!-- .row -->

                    
                </div>
            </div>
        </div>
    </div> <!-- .nk-content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>