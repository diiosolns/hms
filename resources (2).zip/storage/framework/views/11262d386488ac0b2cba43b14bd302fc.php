
<li class="nk-menu-item">
    <a href="<?php echo e(route('owner.dashboard')); ?>" class="nk-menu-link">
        <span class="nk-menu-icon"><em class="icon ni ni-dashboard"></em></span>
        <span class="nk-menu-text">Dashboard</span>
    </a>
</li>

<li class="nk-menu-heading">
    <h6 class="overline-title">System Administration</h6>
</li>

<li class="nk-menu-item">
    <a href="<?php echo e(route('owner.employees.manage')); ?>" class="nk-menu-link">
        <span class="nk-menu-icon"><em class="icon ni ni-users-fill"></em></span>
        <span class="nk-menu-text">User Management</span>
    </a>
</li>

<li class="nk-menu-item">
    <a href="<?php echo e(route('owner.hospitals.manage')); ?>" class="nk-menu-link">
        <span class="nk-menu-icon"><em class="icon ni ni-building"></em></span>
        <span class="nk-menu-text">Hospital & Branches</span>
    </a>
</li>

<li class="nk-menu-item">
    <a href="<?php echo e(route('owner.reports.dashboard')); ?>" class="nk-menu-link">
        <span class="nk-menu-icon"><em class="icon ni ni-trend-up"></em></span>
        <span class="nk-menu-text">System Reports</span>
    </a>
</li>

<li class="nk-menu-item">
    <a href="<?php echo e(route('owner.settings')); ?>" class="nk-menu-link">
        <span class="nk-menu-icon"><em class="icon ni ni-setting-alt"></em></span>
        <span class="nk-menu-text">System Settings</span>
    </a>
</li>


<li class="nk-menu-item">
    <a href="<?php echo e(route('logout')); ?>" class="nk-menu-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        <span class="nk-menu-icon"><em class="icon ni ni-signout"></em></span>
        <span class="nk-menu-text">Logout</span>
    </a>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>
</li><?php /**PATH C:\xampp\htdocs\hms\resources\views/layouts/menu/owner-menu.blade.php ENDPATH**/ ?>