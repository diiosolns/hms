//Properjs
@@include('@@nodeRoot/node_modules/@popperjs/core/dist/umd/popper.min.js')
// Bootstrap
@@include('@@nodeRoot/node_modules/bootstrap/dist/js/bootstrap.min.js')
// Simplebar
@@include('@@nodeRoot/node_modules/simplebar/dist/simplebar.min.js')
// Prism
@@include('@@nodeRoot/node_modules/prismjs/prism.js')
// Clipboard
@@include('@@nodeRoot/node_modules/clipboard/dist/clipboard.min.js')
// choices select js 
@@include('@@nodeRoot/node_modules/choices.js/public/assets/scripts/choices.min.js')
// Sweetalert2
@@include('@@nodeRoot/node_modules/sweetalert2/dist/sweetalert2.min.js')
// simple Data-tables
@@include('@@nodeRoot/node_modules/simple-datatables/dist/umd/simple-datatables.js')
// Chart js
@@include('@@nodeRoot/node_modules/chart.js/dist/chart.min.js')
// Fullcalendar js
@@include('@@nodeRoot/node_modules/fullcalendar/main.min.js')
// jKanban
@@include('@@nodeRoot/node_modules/jkanban/dist/jkanban.min.js')
// DatePicker
@@include('@@nodeRoot/node_modules/vanillajs-datepicker/dist/js/datepicker-full.js')
// svgmap
@@include('@@nodeRoot/node_modules/svg-pan-zoom/dist/svg-pan-zoom.min.js')
@@include('@@nodeRoot/node_modules/svgmap/dist/svgMap.min.js')
// Dropzone
@@include('@@nodeRoot/node_modules/dropzone/dist/dropzone-min.js')
//nouislider
@@include('@@nodeRoot/node_modules/nouislider/dist/nouislider.min.js')
//pristinejs
@@include('@@nodeRoot/node_modules/pristinejs/dist/pristine.min.js')
// pure knob
@@include('@@vendorRoot/js/vendors/pureknob/pureknob.js')
// Functions
@@include('@@vendorRoot/js/vendors/nioapp.js')
