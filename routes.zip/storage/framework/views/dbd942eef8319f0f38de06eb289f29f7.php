<?php $__env->startSection('content'); ?>
    
   <div class="nk-content">
                    <div class="container">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="nk-block-head">
                                    <div class="nk-block-head">
                                        <div class="nk-block-head-between flex-wrap gap g-2 align-items-center">
                                            <div class="nk-block-head-content">
                                                <h2 class="nk-block-title">Patient Registration Form</h2>
                                                    <nav>
                                                        <ol class="breadcrumb breadcrumb-arrow mb-0">
                                                            <?php if(Auth::user()->role === 'receptionist'): ?>
                                                            <li class="breadcrumb-item"><a href="<?php echo e(route('receptionist.dashboard')); ?>">Dashboard</a></li>
                                                            <?php elseif(Auth::user()->role === 'nurse'): ?>
                                                            <li class="breadcrumb-item"><a href="<?php echo e(route('nurse.dashboard')); ?>">Dashboard</a></li>
                                                            <?php elseif(Auth::user()->role === 'doctor'): ?>
                                                            <li class="breadcrumb-item"><a href="<?php echo e(route('doctor.dashboard')); ?>">Dashboard</a></li>
                                                            <?php elseif(Auth::user()->role === 'pharmacist'): ?>
                                                            <li class="breadcrumb-item"><a href="<?php echo e(route('pharmacist.dashboard')); ?>">Dashboard</a></li>
                                                            <?php elseif(Auth::user()->role === 'lab_technician'): ?>
                                                            <li class="breadcrumb-item"><a href="<?php echo e(route('lab_technician.dashboard')); ?>">Dashboard</a></li>
                                                            <?php elseif(Auth::user()->role === 'admin'): ?>
                                                            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                                                            <?php elseif(Auth::user()->role === 'owner'): ?>
                                                            <li class="breadcrumb-item"><a href="<?php echo e(route('owner.dashboard')); ?>">Dashboard</a></li>
                                                            <?php endif; ?>
                                                            <li class="breadcrumb-item"><a href="<?php echo e(route('patients.index')); ?>">Manage Patients</a></li>
                                                            <li class="breadcrumb-item active" aria-current="page">Add patient</li>
                                                        </ol>
                                                    </nav>
                                            </div>
                                            <div class="nk-block-head-content">
                                                <ul class="d-flex gap g-2">
                                                    <li class="d-none d-md-block">
                                                        <a href="<?php echo e(route('patients.index')); ?>" class="btn btn-soft btn-primary"><em class="icon ni ni-user"></em><span>View Patients</span></a>
                                                    </li>
                                                    <li class="d-md-none">
                                                        <a href="<?php echo e(route('patients.index')); ?>" class="btn btn-soft btn-primary btn-icon"><em class="icon ni ni-user"></em></a>
                                                    </li>
                                                </ul>
                                            </div><!-- .nk-block-head-content -->
                                        </div><!-- .nk-block-head-between -->
                                    </div><!-- .nk-block-head -->
                                </div><!-- .nk-block-head -->
                                <div class="nk-block">
                                    <div class="card card-gutter-md">
                                        <div class="card-body">
                                            <div class="bio-block">
                                                <h4 class="bio-block-title mb-4">Register a New Patient</h4>
                                                





                                                <form action="<?php echo e(route('patients.store')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>

                                                    <div class="row g-3">
                                                        <!-- First Name -->
                                                        <div class="col-lg-6">
                                                            <div class="form-group">
                                                                <label for="first_name" class="form-label">First Name <span style="color: red;">*</span></label>
                                                                <div class="form-control-wrap">
                                                                    <input type="text" 
                                                                           class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                                           id="first_name" 
                                                                           name="first_name" 
                                                                           value="<?php echo e(old('first_name')); ?>" 
                                                                           placeholder="First name">
                                                                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Last Name -->
                                                        <div class="col-lg-6">
                                                            <div class="form-group">
                                                                <label for="last_name" class="form-label">Last Name <span style="color: red;">*</span> </label>
                                                                <div class="form-control-wrap">
                                                                    <input type="text" 
                                                                           class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                                           id="last_name" 
                                                                           name="last_name" 
                                                                           value="<?php echo e(old('last_name')); ?>" 
                                                                           placeholder="Last name">
                                                                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Phone -->
                                                        <div class="col-lg-6">
                                                            <div class="form-group">
                                                                <label for="phone" class="form-label">Phone <span style="color: red;">*</span></label>
                                                                <div class="form-control-wrap">
                                                                    <input type="tel" 
                                                                           class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                                           id="phone" 
                                                                           name="phone" 
                                                                           value="<?php echo e(old('phone')); ?>" 
                                                                           placeholder="Phone number">
                                                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Payment Method -->
                                                        <div class="col-lg-6">
                                                            <div class="form-group">
                                                                <label for="pay_method" class="form-label">How to Pay <span style="color: red;">*</span> </label>
                                                                <div class="form-control-wrap">
                                                                    <select class="form-control <?php $__errorArgs = ['pay_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                                            id="pay_method" 
                                                                            name="pay_method">
                                                                        <option value="Cash">Choose how to pay</option>
                                                                        <option value="Cash" <?php echo e(old('pay_method') == 'Cash' ? 'selected' : ''); ?>>Cash</option>
                                                                        <option value="NHIF" <?php echo e(old('pay_method') == 'NHIF' ? 'selected' : ''); ?>>NHIF</option>
                                                                        <option value="AAR" <?php echo e(old('pay_method') == 'AAR' ? 'selected' : ''); ?>>AAR</option>
                                                                        <option value="Strategis" <?php echo e(old('pay_method') == 'Strategis' ? 'selected' : ''); ?>>Strategis</option>
                                                                        <option value="Britam" <?php echo e(old('pay_method') == 'Britam' ? 'selected' : ''); ?>>Britam</option>
                                                                        <option value="Heritage" <?php echo e(old('pay_method') == 'Heritage' ? 'selected' : ''); ?>>Heritage</option>
                                                                    </select>
                                                                    <?php $__errorArgs = ['pay_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Gender -->
                                                        <div class="col-lg-6">
                                                            <div class="form-group">
                                                                <label for="gender" class="form-label">Gender <span style="color: red;">*</span> </label>
                                                                <div class="form-control-wrap">
                                                                    <select class="form-control <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                                            id="gender" 
                                                                            name="gender">
                                                                        <option value="">Select gender</option>
                                                                        <option value="Male" <?php echo e(old('gender') == 'Male' ? 'selected' : ''); ?>>Male</option>
                                                                        <option value="Female" <?php echo e(old('gender') == 'Female' ? 'selected' : ''); ?>>Female</option>
                                                                    </select>
                                                                    <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Email -->
                                                        <div class="col-lg-6">
                                                            <div class="form-group">
                                                                <label for="email" class="form-label">Email address</label>
                                                                <div class="form-control-wrap">
                                                                    <input type="email" 
                                                                           class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                                           id="email" 
                                                                           name="email" 
                                                                           value="<?php echo e(old('email')); ?>" 
                                                                           placeholder="Email address">
                                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Date of Birth -->
                                                        <div class="col-lg-6">
                                                            <div class="form-group">
                                                                <label for="date_of_birth" class="form-label">Date of Birth</label>
                                                                <div class="form-control-wrap">
                                                                    <input type="date" 
                                                                           class="form-control <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                                           id="date_of_birth" 
                                                                           name="date_of_birth" 
                                                                           value="<?php echo e(old('date_of_birth')); ?>">
                                                                    <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>                                               

                                                        <!-- Address -->
                                                        <div class="col-lg-6">
                                                            <div class="form-group">
                                                                <label for="address" class="form-label">Address</label>
                                                                <div class="form-control-wrap">
                                                                    <input type="text" 
                                                                           class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                                           id="address" 
                                                                           name="address" 
                                                                           value="<?php echo e(old('address')); ?>" 
                                                                           placeholder="e.g. California, United States">
                                                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Emergency Contact Name -->
                                                        <div class="col-lg-6">
                                                            <div class="form-group">
                                                                <label for="emergency_contact_name" class="form-label">Emergency Contact Name</label>
                                                                <div class="form-control-wrap">
                                                                    <input type="text" 
                                                                           class="form-control <?php $__errorArgs = ['emergency_contact_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                                           id="emergency_contact_name" 
                                                                           name="emergency_contact_name" 
                                                                           value="<?php echo e(old('emergency_contact_name')); ?>" 
                                                                           placeholder="Emergency contact name">
                                                                    <?php $__errorArgs = ['emergency_contact_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Emergency Contact Phone -->
                                                        <div class="col-lg-6">
                                                            <div class="form-group">
                                                                <label for="emergency_contact_phone" class="form-label">Emergency Contact Phone</label>
                                                                <div class="form-control-wrap">
                                                                    <input type="tel" 
                                                                           class="form-control <?php $__errorArgs = ['emergency_contact_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                                           id="emergency_contact_phone" 
                                                                           name="emergency_contact_phone" 
                                                                           value="<?php echo e(old('emergency_contact_phone')); ?>" 
                                                                           placeholder="Emergency contact phone">
                                                                    <?php $__errorArgs = ['emergency_contact_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <!-- Service -->
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label class="form-label">Service</label>
                                                                <div class="form-control-wrap">
                                                                    <select class="js-select <?php $__errorArgs = ['service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="service_id" id="service_id" data-search="true" data-sort="false">
                                                                        <option value="1">Select Service (Optional)</option>
                                                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($service->id); ?>" <?php echo e(old('service_id') == $service->id ? 'selected' : ''); ?>><?php echo e($service->name); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <?php $__errorArgs = ['service_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>

                                                        <!-- Avoid Nurse Switch -->
                                                        <div class="col-lg-12 g-4">
                                                            <div class="form-check form-switch form-check-lg g-2">
                                                              <input class="form-check-input" type="checkbox" name="avoid_nurse" value="yes" id="flexSwitchDefault">
                                                              <label class="form-check-label" for="flexSwitchDefault">
                                                                Avoid Nurse
                                                                <small style="color: red;"> (Turn on this switch to send Partient details to Doctor direct. Nurse will be bypassed)</small>
                                                              </label>
                                                            </div>
                                                        </div>

                                                        <!-- Hidden hospital & branch -->
                                                        <input type="hidden" name="hospital_id" value="<?php echo e(auth()->user()->hospital_id); ?>">
                                                        <input type="hidden" name="branch_id" value="<?php echo e(auth()->user()->branch_id); ?>">
                                                        <input type="hidden" name="patient_id" value="<?php echo e('PNT' . now()->format('YmdHis') . rand(100,999)); ?>">
                                                        <input type="hidden" name="doctor_id" value="<?php echo e(Auth::id()); ?>">
                                                        
                                                        <!-- Submit -->
                                                        <div class="col-lg-12">
                                                            <button class="btn btn-primary" type="submit">Save Details</button>
                                                        </div>
                                                    </div>
                                                </form>








                                            </div><!-- .bio-block -->
                                        </div><!-- .card-body -->
                                    </div><!-- .card -->
                                </div><!-- .nk-block -->
                            </div>
                        </div>
                    </div>
                </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/patients/create.blade.php ENDPATH**/ ?>