<?php $__env->startSection('content'); ?>
    <div class="nk-content">
        <div class="container">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    
                    <?php if($user): ?>
                        <div class="nk-block-head">
                            <div class="nk-block-head-between flex-wrap gap g-2 align-items-start">
                                <div class="nk-block-head-content">
                                    <div class="d-flex flex-column flex-md-row align-items-md-center">
                                        <div class="media media-huge media-circle">
                                            
                                            <img src="<?php echo e(asset('images/users/def.jpg')); ?>" class="img-thumbnail" alt="<?php echo e($user->first_name); ?>">
                                        </div>
                                        <div class="mt-3 mt-md-0 ms-md-3">
                                            
                                            <h3 class="title mb-1"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h3>
                                            
                                            <span class="small"><?php echo e(ucwords($user->role)); ?></span>
                                            <ul class="nk-list-option pt-1">
                                                
                                                <?php if($user->branch): ?>
                                                    <li><em class="icon ni ni-building"></em><span class="small"><?php echo e($user->branch->name); ?></span></li>
                                                <?php endif; ?>
                                                
                                                <?php if($user->hospital): ?>
                                                    <li><em class="icon ni ni-building"></em><span class="small"><?php echo e($user->hospital->name); ?></span></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div><!-- .nk-block-head-content -->
                            </div><!-- .nk-block-head-between -->
                        </div><!-- .nk-block-head -->
                        
                        <div class="nk-block">
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane show active" id="tab-1" tabindex="0" role="tabpanel">
                                    <div class="card card-gutter-md">
                                        <div class="card-row card-row-lg col-sep col-sep-lg">
                                            <div class="card-aside">
                                                <div class="card-body">
                                                    <div class="bio-block">
                                                        <h4 class="bio-block-title">Details</h4>
                                                        <ul class="list-group list-group-borderless small">
                                                            <li class="list-group-item">
                                                                <span class="title fw-medium w-40 d-inline-block">Account ID:</span>
                                                                
                                                                <span class="text"><?php echo e($user->id); ?></span>
                                                            </li>
                                                            <li class="list-group-item">
                                                                <span class="title fw-medium w-40 d-inline-block">Room ID:</span>
                                                                
                                                                <span class="text"><b><?php echo e($user->room); ?></b></span>
                                                            </li>
                                                            <li class="list-group-item">
                                                                <span class="title fw-medium w-40 d-inline-block">Email:</span>
                                                                
                                                                <span class="text"><?php echo e($user->email); ?></span>
                                                            </li>
                                                            
                                                            <li class="list-group-item">
                                                                <span class="title fw-medium w-40 d-inline-block">Phone:</span>
                                                                <span class="text"><?php echo e($user->phone ?? 'Not provided'); ?></span>
                                                            </li>
                                                            
                                                            <li class="list-group-item">
                                                                <span class="title fw-medium w-40 d-inline-block">Joining Date:</span>
                                                                <span class="text"><?php echo e($user->created_at ? $user->created_at->format('M d, Y') : 'N/A'); ?></span>
                                                            </li>
                                                            
                                                        </ul>
                                                    </div><!-- .bio-block -->
                                                </div><!-- .card-body -->
                                            </div>
                                            <div class="card-content col-sep">
                                                <div class="card-body">
                                                    <div class="bio-block">
                                                        <h4 class="bio-block-title">About Me</h4>
                                                        
                                                        <p>Hey, I'm <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>, <br> I am a <?php echo e(ucwords($user->role)); ?> at <?php echo e($user->branch->name ?? 'N/A'); ?> branch, under the <?php echo e($user->hospital->name ?? 'N/A'); ?> Hospital.</p>
                                                        <p>My passion lies in providing the best possible care for our community. I'm excited to be a part of this team and look forward to contributing to our shared mission.</p>
                                                    </div><!-- .bio-block -->
                                                </div><!-- .card-body -->
                                            </div><!-- .card-content -->
                                        </div><!-- .card-row -->
                                    </div><!-- .card -->
                                </div><!-- .tab-pane -->
                            </div><!-- .tab-content -->
                        </div><!-- .nk-block -->
                    <?php else: ?>
                        
                        <div class="alert alert-danger" role="alert">
                            User not found.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/auth/profile.blade.php ENDPATH**/ ?>