<?php $__env->startSection('content'); ?>
<div class="nk-content">
    <div class="container">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="nk-block-head">
                    <div class="nk-block-head-between flex-wrap gap g-2">
                        <div class="nk-block-head-content">
                            <h2 class="nk-block-title">My Appointments</h2>
                            <nav>
                                <ol class="breadcrumb breadcrumb-arrow mb-0">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('nurse.dashboard')); ?>">Dashboard</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Manage Appointments</li>
                                </ol>
                            </nav>
                        </div>
                        <div class="nk-block-head-content">
                            <!-- you can add button here -->
                        </div>
                    </div><!-- .nk-block-head-between -->
                </div><!-- .nk-block-head -->

                <div class="nk-block">
                    <div class="card">
                        <table class="datatable-init table" data-nk-container="table-responsive">
                            <thead class="table-light">
                                <tr>
                                    <th class="tb-col"><span class="overline-title">Patient</span></th>
                                    <th class="tb-col"><span class="overline-title">Doctor</span></th>
                                    <th class="tb-col"><span class="overline-title">Date</span></th>
                                    <th class="tb-col"><span class="overline-title">Time</span></th>
                                    <th class="tb-col"><span class="overline-title">Reason</span></th>
                                    <th class="tb-col"><span class="overline-title">Status</span></th>
                                    <th class="tb-col tb-col-end" data-sortable="false">
                                        <span class="overline-title">Action</span>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="tb-col"><?php echo e($appointment->patient->first_name ?? 'N/A'); ?> <?php echo e($appointment->patient->last_name ?? ''); ?></td>
                                    <td class="tb-col"><?php echo e($appointment->doctor->first_name ?? 'N/A'); ?> <?php echo e($appointment->doctor->last_name ?? ''); ?></td>
                                    <td class="tb-col">
                                        <?php echo e(\Carbon\Carbon::parse($appointment->appointment_date)->format('Y-m-d')); ?>

                                    </td>
                                    <td class="tb-col">
                                        <?php echo e(\Carbon\Carbon::parse($appointment->appointment_time)->format('H:i')); ?>

                                    </td>
                                    <td class="tb-col"><?php echo e($appointment->reason ?? '-'); ?></td>
                                    <td class="tb-col">
                                        <?php if($appointment->status === 'Scheduled'): ?>
                                            <span class="badge text-bg-info-soft"><?php echo e($appointment->status); ?></span>
                                        <?php elseif($appointment->status === 'Completed'): ?>
                                            <span class="badge text-bg-success-soft"><?php echo e($appointment->status); ?></span>
                                        <?php else: ?>
                                            <span class="badge text-bg-danger-soft"><?php echo e($appointment->status); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="tb-col tb-col-end">
                                        <div class="dropdown">
                                            <a href="#" class="btn btn-sm btn-icon btn-zoom me-n1" data-bs-toggle="dropdown">
                                                <em class="icon ni ni-more-v"></em>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-sm dropdown-menu-end">
                                                <ul class="link-list link-list-hover-bg-primary link-list-md">
                                                    <li>
                                                        <a href="<?php echo e(route('appointments.show', $appointment->id)); ?>">
                                                            <em class="icon ni ni-eye"></em><span>View</span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="<?php echo e(route('appointments.edit', $appointment->id)); ?>">
                                                            <em class="icon ni ni-edit"></em><span>Edit</span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <form action="<?php echo e(route('appointments.destroy', $appointment->id)); ?>" method="POST" onsubmit="return confirm('Are you sure?');">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" class="dropdown-item">
                                                                <em class="icon ni ni-trash"></em><span>Delete</span>
                                                            </button>
                                                        </form>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div><!-- dropdown -->
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center text-muted">No appointments found.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div><!-- .card -->
                </div><!-- .nk-block -->

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/nurse/appointments.blade.php ENDPATH**/ ?>