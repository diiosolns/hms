<?php $__env->startSection('content'); ?>
                <div class="nk-content">
                    <div class="container">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="nk-block-head">
                                    <div class="nk-block-head-between flex-wrap gap g-2">
                                        <div class="nk-block-head-content">
                                            <h2 class="nk-block-title">Pendng Invoices</h2>
                                                <nav>
                                                    <ol class="breadcrumb breadcrumb-arrow mb-0">
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('receptionist.dashboard')); ?>">Dashboard</a></li>
                                                        <li class="breadcrumb-item active" aria-current="page">Manage Invoices</li>
                                                    </ol>
                                                </nav>
                                        </div>
                                        <div class="nk-block-head-content">
                                            <ul class="d-flex">
                                                <!-- ADD ANY BUTTON HERE -->
                                            </ul>
                                        </div>
                                    </div><!-- .nk-block-head-between -->
                                </div><!-- .nk-block-head -->

                                <div class="nk-block">
                                    <div class="card">
                                        <table class="datatable-init table" data-nk-container="table-responsive">
                                            <thead class="table-light">
                                                <tr>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Invoice No.</span>
                                                    </th>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Amount (TZS)</span>
                                                    </th>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Date</span>
                                                    </th>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Last Update</span>
                                                    </th>
                                                    <th class="tb-col tb-col-md">
                                                        <span class="overline-title">Patient</span>
                                                    </th>
                                                    <th class="tb-col ">
                                                        <span class="overline-title">Registered by</span>
                                                    </th>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Status</span>
                                                    </th>
                                                    <th class="tb-col tb-col-end" data-sortable="false">
                                                        <span class="overline-title">Action</span>
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $pendingInvoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td class="tb-col">
                                                        <div class="media-group">
                                                            <div class="media media-md media-middle media-circle text-bg-primary-soft">
                                                                <span class="smaller">
                                                                    <?php echo e(strtoupper(substr($inv->invoice_number, 0, 2) )); ?>

                                                                </span>
                                                            </div>
                                                            <div class="media-text">
                                                                <a href="<?php echo e(route('invoices.show', $inv->id)); ?>" class="title">
                                                                    <?php echo e($inv->invoice_number); ?>

                                                                </a>
                                                                <span class="small text"><?php echo e($inv->status); ?></span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="tb-col"><?php echo e(number_format($inv->total_amount, 0)); ?></td>
                                                    <td class="tb-col"><?php echo e($inv->invoice_date ? \Carbon\Carbon::parse($inv->invoice_date)->format('M d, Y') : 'N/A'); ?></td>
                                                    <td class="tb-col">
                                                        <span class="small"><?php echo e($inv->updated_at ? $inv->updated_at->format('M d, h:i A') : 'N/A'); ?></span>
                                                    </td>
                                                    <td class="tb-col tb-col-md"><?php echo e($inv->patient->first_name . ' ' . $inv->patient->last_name); ?></td>
                                                    <td class="tb-col "><?php echo e($inv->user->first_name . ' ' . $inv->user->last_name); ?></td>
                                                    <td class="tb-col">
                                                        <?php if($inv->status === 'Active'): ?>
                                                            <span class="badge text-bg-success-soft"><?php echo e($inv->status); ?></span>
                                                        <?php else: ?>
                                                            <span class="badge text-bg-danger-soft"><?php echo e($inv->status); ?></span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="tb-col tb-col-end">
                                                        <a href="<?php echo e(route('invoices.show', $inv->id)); ?>" class="btn btn-sm btn-outline-primary">
                                                            View
                                                        </a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="8" class="text-center text-bg-success-soft">No pending invoices found.</td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div><!-- .card -->
                                </div><!-- .nk-block -->
                            </div>
                        </div>
                    </div>
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/receptionist/billing/index.blade.php ENDPATH**/ ?>