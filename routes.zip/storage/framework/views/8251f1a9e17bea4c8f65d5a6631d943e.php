<?php $__env->startSection('content'); ?>
    
    <div class="nk-content">
        <div class="container">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    <div class="nk-block-head">
                        <div class="nk-block-head-between flex-wrap gap g-2">
                            <div class="nk-block-head-content">
                                <h2 class="nk-block-title"><?php echo e($asset->name); ?></h2>
                                <nav>
                                    <ol class="breadcrumb breadcrumb-arrow mb-0">
                                        <li class="breadcrumb-item"><a href="<?php echo e(route('assets.asset.index')); ?>">Assets</a></li>
                                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($asset->serial_number); ?></li>
                                        <li class="breadcrumb-item active" aria-current="page"><?php echo e($asset->name); ?></li>
                                    </ol>
                                </nav>
                            </div>
                            <div class="nk-block-head-content">
                                <ul class="d-flex">
                                    <?php if(in_array(Auth::user()->role, ['admin', 'owner'])): ?>
                                    <li>
                                        <a href="<?php echo e(route('assets.maintenances.create', $asset )); ?>" class="btn btn-md d-md-none btn-primary" >
                                            <em class="icon ni ni-plus"></em>
                                            <span>Add</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('assets.maintenances.create', $asset )); ?>" class="btn btn-primary d-none d-md-inline-flex" >
                                            <em class="icon ni ni-plus"></em>
                                            <span>Add Maintenance Record</span>
                                        </a>
                                    </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div><!-- .nk-block-head-between -->
                    </div><!-- .nk-block-head -->

                    <div class="nk-block">
                        <div class="card">
                            
                            <table class="datatable-init table" data-nk-container="table-responsive">
                                <thead class="table-light">
                                    <tr>
                                        <th class="tb-col">
                                            <span class="overline-title">Description</span>
                                        </th>
                                        <th class="tb-col">
                                            <span class="overline-title">Maintenance Date</span>
                                        </th>
                                        <th class="tb-col tb-col-xl">
                                            <span class="overline-title">Type</span>
                                        </th>
                                        <th class="tb-col tb-col-md">
                                            <span class="overline-title">Cost (TZS)</span>
                                        </th>
                                        <th class="tb-col ">
                                            <span class="overline-title">Performed By</span>
                                        </th>
                                        <th class="tb-col">
                                            <span class="overline-title">Status</span>
                                        </th>
                                        <th class="tb-col tb-col-end" data-sortable="false">
                                            <span class="overline-title">Action</span>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    <?php $__empty_1 = true; $__currentLoopData = $maintenances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="tb-col">
                                            <div class="media-group">
                                                <div class="media media-md media-middle media-circle text-bg-info-soft">
                                                    
                                                    <em class="icon ni ni-setting"></em>
                                                </div>
                                                <div class="media-text">
                                                    <span class="small text"><?php echo e($record->details ?? 'No description'); ?></span>
                                                </div>
                                            </div>
                                        </td>
                                        
                                        <td class="tb-col"><?php echo e(\Carbon\Carbon::parse($record->maintenance_date)->format('M d, Y')); ?></td>
                                        <td class="tb-col tb-col-xl"><?php echo e($record->type); ?></td>
                                        <td class="tb-col tb-col-md"><?php echo e(number_format($record->cost, 0)); ?></td>
                                        <td class="tb-col "><?php echo e($record->performed_by); ?></td>
                                        <td class="tb-col">
                                            <?php if($record->status === 'Completed'): ?>
                                                <span class="badge text-bg-success-soft"><?php echo e($record->status); ?></span>
                                            <?php elseif($record->status === 'Pending'): ?>
                                                <span class="badge text-bg-warning-soft"><?php echo e($record->status); ?></span>
                                            <?php else: ?>
                                                <span class="badge text-bg-success-soft"><?php echo e('Completed'); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="tb-col tb-col-end">
                                            <div class="dropdown">
                                                <a href="#" class="btn btn-sm btn-icon btn-zoom me-n1" data-bs-toggle="dropdown">
                                                    <em class="icon ni ni-more-v"></em>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-sm dropdown-menu-end">
                                                    <div class="dropdown-content py-1">
                                                        <ul class="link-list link-list-hover-bg-primary link-list-md">
                                                            <li>
                                                                <a href="<?php echo e(route('assets.maintenances.edit', [$asset->id, $record->id])); ?>">
                                                                    <em class="icon ni ni-edit"></em><span>Edit Record</span>
                                                                </a>
                                                            </li>
                                                            <li>
                                                                <form action="<?php echo e(route('assets.maintenances.destroy', [$asset->id, $record->id])); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this maintenance record?');">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                    <button type="submit" class="dropdown-item">
                                                                        <em class="icon ni ni-trash"></em><span>Delete Record</span>
                                                                    </button>
                                                                </form>
                                                            </li>
                                                            <li>
                                                                <a href="<?php echo e(route('assets.maintenances.show', [$asset->id, $record->id] )); ?>">
                                                                    <em class="icon ni ni-eye"></em><span>View Details</span>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div><!-- dropdown -->
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="8" class="text-center text-muted">No maintenance records found for this asset.</td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div><!-- .card -->
                    </div><!-- .nk-block -->

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/assets/maintenances/index.blade.php ENDPATH**/ ?>