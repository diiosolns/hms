<?php $__env->startSection('content'); ?>
    <div class="nk-content">
        <div class="container">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    
                    <?php if($user): ?>
                        <div class="nk-block-head">
                            <div class="nk-block-head-between flex-wrap gap g-2 align-items-start">
                                <div class="nk-block-head-content">
                                    <div class="d-flex flex-column flex-md-row align-items-md-center">
                                        <div class="media media-huge media-circle">
                                            
                                            <img src="<?php echo e(asset('images/users/def.jpg')); ?>" class="img-thumbnail" alt="<?php echo e($user->first_name); ?>">
                                        </div>
                                        <div class="mt-3 mt-md-0 ms-md-3">
                                            
                                            <h3 class="title mb-1"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h3>
                                            
                                            <span class="small"><?php echo e(ucwords($user->role)); ?></span>
                                            <ul class="nk-list-option pt-1">
                                                
                                                <?php if($user->branch): ?>
                                                    <li><em class="icon ni ni-building"></em><span class="small"><?php echo e($user->branch->name); ?></span></li>
                                                <?php endif; ?>
                                                
                                                <?php if($user->hospital): ?>
                                                    <li><em class="icon ni ni-building"></em><span class="small"><?php echo e($user->hospital->name); ?></span></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div><!-- .nk-block-head-content -->
                            </div><!-- .nk-block-head-between -->
                        </div><!-- .nk-block-head -->


                        


                        
                        <div class="nk-block">
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane show active" id="tab-1" tabindex="0" role="tabpanel">
                                    <div class="card card-gutter-md">
                                        <div class="card-row card-row-lg col-sep col-sep-lg">
                                            <div class="card-aside">
                                                <div class="card-body">
                                                    <div class="bio-block">
                                                        <h4 class="bio-block-title">Details</h4>
                                                        <ul class="list-group list-group-borderless small">
                                                            <li class="list-group-item">
                                                                <span class="title fw-medium w-40 d-inline-block">Account ID:</span>
                                                                
                                                                <span class="text"><?php echo e($user->id); ?></span>
                                                            </li>
                                                            <li class="list-group-item">
                                                                <span class="title fw-medium w-40 d-inline-block">Room ID:</span>
                                                                
                                                                <span class="text"><b><?php echo e($user->room); ?></b></span>
                                                            </li>
                                                            <li class="list-group-item">
                                                                <span class="title fw-medium w-40 d-inline-block">Email:</span>
                                                                
                                                                <span class="text"><?php echo e($user->email); ?></span>
                                                            </li>
                                                            
                                                            <li class="list-group-item">
                                                                <span class="title fw-medium w-40 d-inline-block">Phone:</span>
                                                                <span class="text"><?php echo e($user->phone ?? 'Not provided'); ?></span>
                                                            </li>
                                                            
                                                            <li class="list-group-item">
                                                                <span class="title fw-medium w-40 d-inline-block">Joining Date:</span>
                                                                <span class="text"><?php echo e($user->created_at ? $user->created_at->format('M d, Y') : 'N/A'); ?></span>
                                                            </li>
                                                            
                                                        </ul>
                                                    </div><!-- .bio-block -->
                                                </div><!-- .card-body -->
                                            </div>
                                            <div class="card-content card-gutter-md">
                                                <div class="card-body">
                                                    <div class="bio-block">
                                                        <h4 class="bio-block-title">Change Password</h4>
                                                        <p>
                                                            To update your password, please enter your current password followed by your new one in the fields below. The new password will take effect the next time you log in.
                                                        </p>

                                                        <!-- Success Message -->
                                                        <?php if(session('status')): ?>
                                                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                                                <?php echo e(session('status')); ?>

                                                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                                            </div>
                                                        <?php endif; ?>

                                                        <!-- Error Message -->
                                                        <?php if(session('error')): ?>
                                                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                                                <?php echo e(session('error')); ?>

                                                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                                            </div>
                                                        <?php endif; ?>

                                                         <!-- General Validation Error List -->
                                                        <?php if($errors->any()): ?>
                                                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                                                <ul class="list-disc list-inside">
                                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <li><?php echo e($error); ?></li>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </ul>
                                                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                                            </div>
                                                        <?php endif; ?>
                                                        <form action="<?php echo e(route('user.password.update')); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            
                                                            <!-- Current Password -->
                                                            <div class="form-group mt-2">
                                                                <div class="form-control-wrap">
                                                                    <div class="form-control-icon start"><em class="icon ni ni-lock"></em></div>
                                                                    <input type="password" class="form-control" name="current_password" id="current_password" placeholder="Enter current Password" required>
                                                                </div>
                                                            </div>

                                                            <!-- New Password -->
                                                            <div class="form-group mt-2">
                                                                <div class="form-control-wrap">
                                                                    <div class="form-control-icon start"><em class="icon ni ni-lock-alt"></em></div>
                                                                    <input type="password" class="form-control" name="new_password" id="new_password" placeholder="Enter new password" required>
                                                                </div>
                                                            </div>

                                                            <!-- Re-enter New Password -->
                                                            <div class="form-group mt-2">
                                                                <div class="form-control-wrap">
                                                                    <div class="form-control-icon start"><em class="icon ni ni-lock-alt-fill"></em></div>
                                                                    <input type="password" class="form-control" name="new_password_confirmation" id="confirm_password" placeholder="Re-enter new password" required>
                                                                </div>
                                                            </div>
                                                            
                                                            <!-- Submit Button -->
                                                            <div class="form-group mt-4">
                                                                <button type="submit" class="btn btn-primary">Update Password</button>
                                                            </div>
                                                        </form>

                                                        
                                                        
                                                    </div><!-- .bio-block -->
                                                </div><!-- .card-body -->
                                            </div><!-- .card-content -->
                                        </div><!-- .card-row -->
                                    </div><!-- .card -->
                                </div><!-- .tab-pane -->
                            </div><!-- .tab-content -->
                        </div><!-- .nk-block -->
                    <?php else: ?>
                        
                        <div class="alert alert-danger" role="alert">
                            User not found.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/auth/settings.blade.php ENDPATH**/ ?>