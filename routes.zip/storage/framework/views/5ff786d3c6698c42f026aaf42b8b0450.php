<?php $__env->startSection('content'); ?>
    
    <div class="nk-content">
        <div class="container-fluid">
            <div class="nk-content-inner">
                <div class="nk-content-body">

                    <div class="nk-block-head">
                                    <div class="nk-block-head-between flex-wrap gap g-2">
                                        <div class="nk-block-head-content">
                                            <h2 class="nk-block-title">Laboratory Tests Requests</h2>
                                                <nav>
                                                    <ol class="breadcrumb breadcrumb-arrow mb-0">
                                                        <?php if(Auth::user()->role === 'receptionist'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('receptionist.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'nurse'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('nurse.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'doctor'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('doctor.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'pharmacist'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('pharmacist.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'lab_technician'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('lab_technician.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'admin'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'owner'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('owner.dashboard')); ?>">Dashboard</a></li>
                                                        <?php endif; ?>

                                                        <?php if(Auth::user()->role === 'lab_technician'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('lab_technician.labtests.requests')); ?>">Lab Requests</a></li>
                                                        <?php endif; ?>
                                                        <li class="breadcrumb-item active" aria-current="page">Update Test Requests</li>
                                                    </ol>
                                                </nav>
                                        </div>
                                        <div class="nk-block-head-content">
                                            
                                        </div>
                                    </div><!-- .nk-block-head-between -->
                                </div><!-- .nk-block-head -->



                
                    <!-- PATIENTS PENDING LAB TESTS -->
                    <div class="row g-gs mt-4">
                        <div class="col-xxl-12">
                            <div class="card h-100">
                                <div class="card-body flex-grow-0 py-2">
                                    <div class="card-title-group">
                                        <div class="card-title">
                                            <h4 class="title">Lab Tests Requests</h4>
                                        </div>
                                        <div class="card-tools">
                                            <div class="dropdown">
                                                <a href="#" class="btn btn-sm btn-icon btn-zoom me-n1" data-bs-toggle="dropdown">
                                                    <em class="icon ni ni-more-v"></em>
                                                </a>
                                                <ul class="dropdown-menu dropdown-menu-sm dropdown-menu-end">
                                                    <li>
                                                        <div class="dropdown-header pt-2 pb-0">
                                                            <h6 class="mb-0">Options</h6>
                                                        </div>
                                                    </li>
                                                    <li><hr class="dropdown-divider"></li>
                                                    <li><a href="#" class="dropdown-item">Sort A-Z</a></li>
                                                    <li><a href="#" class="dropdown-item">Sort Z-A</a></li>
                                                </ul>
                                            </div><!-- dropdown -->
                                        </div>
                                    </div><!-- .card-title-group -->
                                </div><!-- .card-body -->

                                <div class="table-responsive">
                                    <table class="table table-middle mb-0">
                                        <thead class="table-light table-head-md">
                                            <tr>
                                                <th class="tb-col">
                                                    <span class="overline-title">Patient Name</span>
                                                </th>
                                                <th class="tb-col tb-col-end tb-col-sm">
                                                    <span class="overline-title">Requester</span>
                                                </th>
                                                <th class="tb-col tb-col-end tb-col-sm">
                                                    <span class="overline-title">Request Date</span>
                                                </th>
                                                <th class="tb-col tb-col-end tb-col-sm">
                                                    <span class="overline-title">Time</span>
                                                </th>
                                                <th class="tb-col tb-col-end">
                                                    <span class="overline-title">Status</span>
                                                </th>
                                                <th class="tb-col tb-col-end">
                                                    <span class="overline-title">Actions</span>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $labRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td class="tb-col">
                                                        <div class="media-group">
                                                            <div class="media media-md flex-shrink-0 media-middle media-circle text-bg-info-soft">
                                                                <span class="smaller">
                                                                    <?php echo e(strtoupper(substr($lab->patient->first_name,0,1))); ?><?php echo e(strtoupper(substr($lab->patient->last_name,0,1))); ?>

                                                                </span>
                                                            </div>
                                                            <div class="media-text">
                                                                <span class="title"><?php echo e($lab->patient->first_name); ?> <?php echo e($lab->patient->last_name); ?></span>
                                                                <span class="text smaller">
                                                                    Requested at: <?php echo e(\Carbon\Carbon::parse($lab->requested_at)->format('M d, Y h:i A')); ?>

                                                                </span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="tb-col tb-col-end tb-col-sm">
                                                        <span class="small"><?php echo e($lab->requester->first_name ?? 'N/A'); ?></span>
                                                    </td>
                                                    <td class="tb-col tb-col-end tb-col-sm">
                                                        <span class="small">
                                                            <?php echo e($lab->requested_at ? \Carbon\Carbon::parse($lab->requested_at)->format('M d, Y') : 'N/A'); ?>

                                                        </span>
                                                    </td>
                                                    <td class="tb-col tb-col-end tb-col-sm">
                                                        <span class="small">
                                                            <?php echo e($lab->requested_at ? \Carbon\Carbon::parse($lab->requested_at)->format('H:i') : 'N/A'); ?>

                                                        </span>
                                                    </td>
                                                    <td class="tb-col tb-col-end">
                                                        <span class="badge 
                                                            <?php echo e($lab->status === 'Closed' ? 'bg-success' : 'bg-warning'); ?>">
                                                            <?php echo e($lab->status); ?>

                                                        </span>
                                                    </td>
                                                    <td class="tb-col tb-col-end">
                                                        <a href="<?php echo e(route('lab_technician.labtests.requests.show', $lab->id)); ?>" class="btn btn-sm btn-outline-primary">
                                                            View
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="5" class="text-center text-muted">No lab requests found.</td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div><!-- .table-responsive -->

                                <div class="card-footer text-center">
                                    <?php echo e($labRequests->links('pagination::bootstrap-5')); ?>

                                </div>
                            </div><!-- .card -->
                        </div>
                    </div>
                    <!-- END PATIENTS PENDING LAB TESTS -->




                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/lab_technician/requests.blade.php ENDPATH**/ ?>