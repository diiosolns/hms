<?php $__env->startSection('content'); ?>
    <div class="nk-main">
        <div class="nk-wrap align-items-center justify-content-center">
            <div class="container">
                <div class="nk-block">
                    <div class="nk-block-content wide-sm text-center mx-auto">
                        <img src="<?php echo e(asset('images/error/c.png')); ?>" alt="" class="mb-5">
                        <h2 class="nk-error-title mb-2">Oops! Too many requests. Please slow down.</h2>
                        <p class="nk-error-text">We are very sorry for inconvenience. </p>
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-primary mt-1"><em class="icon ni ni-arrow-left"></em><span>Back To Home</span></a>
                    </div>
                </div>
            </div>
        </div><!-- .nk-wrap -->
    </div> <!-- .nk-main -->
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.err', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/errors/419.blade.php ENDPATH**/ ?>