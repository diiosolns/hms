<?php $__env->startSection('content'); ?>
    
    <div class="nk-content">
                    <div class="container">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="nk-block-head">
                                    <div class="nk-block-head-between flex-wrap gap g-2">
                                        <div class="nk-block-head-content">
                                            <h2 class="nk-block-title">Pharmacy Items</h2>
                                                <nav>
                                                    <ol class="breadcrumb breadcrumb-arrow mb-0">
                                                        <?php if(Auth::user()->role === 'receptionist'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('receptionist.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'nurse'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('nurse.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'doctor'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('doctor.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'pharmacist'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('pharmacist.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'lab_technician'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('lab_technician.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'admin'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'owner'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('owner.dashboard')); ?>">Dashboard</a></li>
                                                        <?php endif; ?>

                                                        <?php if(Auth::user()->role === 'admin'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('pharmacy.create')); ?>">Add new Item</a></li>
                                                        <?php endif; ?>
                                                        <li class="breadcrumb-item active" aria-current="page">Manage Pharmacy Items</li>
                                                    </ol>
                                                </nav>
                                        </div>
                                        <div class="nk-block-head-content">
                                            <ul class="d-flex">
                                                <?php if(Auth::user()->role === 'admin'): ?>
                                                <li>
                                                    <a href="<?php echo e(route('pharmacy.create')); ?>" class="btn btn-md d-md-none btn-primary" >
                                                        <em class="icon ni ni-plus"></em>
                                                        <span>Add</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="<?php echo e(route('pharmacy.create')); ?>" class="btn btn-primary d-none d-md-inline-flex" >
                                                        <em class="icon ni ni-plus"></em>
                                                        <span>Add Pharmacy Item</span>
                                                    </a>
                                                </li>

                                                <?php elseif(Auth::user()->role === 'pharmacist'): ?>
                                                    <li>
                                                        <a href="<?php echo e(route('pharmacist.items.create')); ?>" class="btn btn-md d-md-none btn-primary" >
                                                            <em class="icon ni ni-plus"></em>
                                                            <span>Add</span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="<?php echo e(route('pharmacist.items.create')); ?>" class="btn btn-primary d-none d-md-inline-flex" >
                                                            <em class="icon ni ni-plus"></em>
                                                            <span>Add Pharmacy Item</span>
                                                        </a>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div><!-- .nk-block-head-between -->
                                </div><!-- .nk-block-head -->












                                <div class="nk-block">
                                    <div class="card">
                                        <table class="datatable-init table" data-nk-container="table-responsive">
                                            <thead class="table-light">
                                                <tr>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Pharmacy Item</span>
                                                    </th>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Category</span>
                                                    </th>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Bland</span>
                                                    </th>
                                                    <th class="tb-col tb-col-xl">
                                                        <span class="overline-title">Form</span>
                                                    </th>
                                                    <th class="tb-col tb-col-md">
                                                        <span class="overline-title">Unit</span>
                                                    </th>
                                                    <th class="tb-col ">
                                                        <span class="overline-title">Price (TZS)</span>
                                                    </th>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Status</span>
                                                    </th>
                                                    <th class="tb-col tb-col-end" data-sortable="false">
                                                        <span class="overline-title">Action</span>
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $pharmacyItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pharmacy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td class="tb-col">
                                                        <div class="media-group">
                                                            <div class="media media-md media-middle media-circle text-bg-primary-soft">
                                                                <span class="smaller">
                                                                    <?php echo e(strtoupper(substr($pharmacy->code, 0, 2) )); ?>

                                                                </span>
                                                            </div>
                                                            <div class="media-text">
                                                                <a href="<?php echo e(route('pharmacy.show', $pharmacy->id)); ?>" class="title">
                                                                    <?php echo e($pharmacy->name); ?>

                                                                </a>
                                                                <span class="small text"><?php echo e($pharmacy->code); ?></span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="tb-col"><?php echo e($pharmacy->category); ?></td>
                                                    <td class="tb-col"><?php echo e($pharmacy->brand_name); ?></td>
                                                    <td class="tb-col tb-col-xl"><?php echo e($pharmacy->form); ?></td>
                                                    <td class="tb-col tb-col-md"><?php echo e($pharmacy->unit); ?></td>
                                                    <td class="tb-col "><?php echo e($pharmacy->price); ?></td>
                                                    <td class="tb-col">
                                                        <?php if($pharmacy->status === 'Active'): ?>
                                                            <span class="badge text-bg-success-soft"><?php echo e($pharmacy->status); ?></span>
                                                        <?php else: ?>
                                                            <span class="badge text-bg-danger-soft"><?php echo e($pharmacy->status); ?></span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="tb-col tb-col-end">
                                                        <div class="dropdown">
                                                            <a href="#" class="btn btn-sm btn-icon btn-zoom me-n1" data-bs-toggle="dropdown">
                                                                <em class="icon ni ni-more-v"></em>
                                                            </a>
                                                            <div class="dropdown-menu dropdown-menu-sm dropdown-menu-end">
                                                                <div class="dropdown-content py-1">
                                                                    <ul class="link-list link-list-hover-bg-primary link-list-md">
                                                                            <li>
                                                                                <a href="<?php echo e(route('pharmacy.edit', $pharmacy->id)); ?>">
                                                                                    <em class="icon ni ni-edit"></em><span>Edit</span>
                                                                                </a>
                                                                            </li>
                                                                            <li>
                                                                                <form action="<?php echo e(route('pharmacy.destroy', $pharmacy->id)); ?>" method="POST" onsubmit="return confirm('Are you sure?');">
                                                                                    <?php echo csrf_field(); ?>
                                                                                    <?php echo method_field('DELETE'); ?>
                                                                                    <button type="submit" class="dropdown-item">
                                                                                        <em class="icon ni ni-trash"></em><span>Delete</span>
                                                                                    </button>
                                                                                </form>
                                                                            </li>
                                                                            <li>
                                                                                <a href="<?php echo e(route('pharmacy.show', $pharmacy->id)); ?>">
                                                                                    <em class="icon ni ni-eye"></em><span>View Details</span>
                                                                                </a>
                                                                            </li>
                                                                        </ul>
                                                                </div>
                                                            </div>
                                                        </div><!-- dropdown -->
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="6" class="text-center text-muted">No services found.</td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div><!-- .card -->
                                </div><!-- .nk-block -->

                            </div>
                        </div>
                    </div>
                </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/pharmacy/items/index.blade.php ENDPATH**/ ?>