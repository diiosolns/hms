<?php $__env->startSection('content'); ?>
    <div class="nk-content">
        <div class="container">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                        <div class="nk-block-head">
                            <div class="nk-block-head-between flex-wrap gap g-2 align-items-start">
                                <div class="nk-block-head-content">
                                    <div class="d-flex flex-column flex-md-row align-items-md-center">
                                        <div class="media media-huge media-middle media-circle text-bg-primary-soft">
                                           <span class="huge"><?php echo e(strtoupper(substr($labTest->code, 0, 2))); ?></span>
                                        </div>
                                        <div class="mt-3 mt-md-0 ms-md-3">
                                            
                                            <h3 class="title mb-1"><?php echo e($labTest->name); ?> </h3>
                                            
                                            <span class="badge bg-primary">Code: <?php echo e($labTest->code); ?></span>
                                            <ul class="nk-list-option pt-1">
                                                
                                                <?php if($labTest->category): ?>
                                                    <li><em class="icon ni ni-building"></em>
                                                        <span class="small"><?php echo e($labTest->category); ?></span>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div><!-- .nk-block-head-content -->
                                <div class="nk-block-head-content">
                                                
                                </div><!-- .nk-block-head-content -->

                            </div><!-- .nk-block-head-between -->
                        </div><!-- .nk-block-head -->

                            
                        
                        <div class="nk-block">
                            <div class="nk-content" >
                                <div class="card card-bordered">
                                    <div class="card-body">
                                        <h4 class="card-title mb-3">Lab Test Details</h4>

                                        <?php if($labTest): ?>
                                            <ul class="list-group list-group-borderless small">
                                                <li class="list-group-item">
                                                    <span class="fw-medium w-40 d-inline-block">Code:</span>
                                                    <span class="text"><?php echo e($labTest->code); ?></span>
                                                </li>
                                                <li class="list-group-item">
                                                    <span class="fw-medium w-40 d-inline-block">Name:</span>
                                                    <span class="text"><?php echo e($labTest->name); ?></span>
                                                </li>
                                                <li class="list-group-item">
                                                    <span class="fw-medium w-40 d-inline-block">Category:</span>
                                                    <span class="text"><?php echo e($labTest->category ?? 'N/A'); ?></span>
                                                </li>
                                                <li class="list-group-item">
                                                    <span class="fw-medium w-40 d-inline-block">Description:</span>
                                                    <span class="text"><?php echo e($labTest->description ?? 'No description provided'); ?></span>
                                                </li>
                                                <li class="list-group-item">
                                                    <span class="fw-medium w-40 d-inline-block">Sample Type:</span>
                                                    <span class="text"><?php echo e($labTest->sample_type ?? 'N/A'); ?></span>
                                                </li>
                                                <li class="list-group-item">
                                                    <span class="fw-medium w-40 d-inline-block">Method:</span>
                                                    <span class="text"><?php echo e($labTest->method ?? 'N/A'); ?></span>
                                                </li>
                                                <li class="list-group-item">
                                                    <span class="fw-medium w-40 d-inline-block">Normal Range:</span>
                                                    <span class="text"><?php echo e($labTest->normal_range ?? '-'); ?></span>
                                                </li>
                                                <li class="list-group-item">
                                                    <span class="fw-medium w-40 d-inline-block">Unit:</span>
                                                    <span class="text"><?php echo e($labTest->unit ?? '-'); ?></span>
                                                </li>
                                                <li class="list-group-item">
                                                    <span class="fw-medium w-40 d-inline-block">Price:</span>
                                                    <span class="text"><?php echo e(number_format($labTest->price, 2)); ?></span>
                                                </li>
                                                <li class="list-group-item">
                                                    <span class="fw-medium w-40 d-inline-block">Status:</span>
                                                    <span class="badge bg-<?php echo e($labTest->status === 'Active' ? 'success' : 'danger'); ?>">
                                                        <?php echo e($labTest->status); ?>

                                                    </span>
                                                </li>
                                                <li class="list-group-item">
                                                    <span class="fw-medium w-40 d-inline-block">Created On:</span>
                                                    <span class="text">
                                                        <?php echo e(\Carbon\Carbon::parse($labTest->created_at)->format('M d, Y')); ?>

                                                    </span>
                                                </li>
                                            </ul>
                                        <?php else: ?>
                                            <p class="text-muted">No lab test details available.</p>
                                        <?php endif; ?>
                                    </div>
                                </div>

                            </div><!-- .nk-content -->
                        </div><!-- .nk-block --> 
                    </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/lab_technician/show_catalog.blade.php ENDPATH**/ ?>