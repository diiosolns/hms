<?php $__env->startSection('content'); ?>
<div class="nk-content">
    <div class="container">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="nk-block-head">
                    <div class="nk-block-head-between flex-wrap gap g-2">
                        <div class="nk-block-head-content">
                            <h2 class="nk-block-title">Patient Search</h2>
                            <nav>
                                <ol class="breadcrumb breadcrumb-arrow mb-0">
                                    <?php if(Auth::user()->role === 'receptionist'): ?>
                                        <li class="breadcrumb-item"><a href="<?php echo e(route('receptionist.dashboard')); ?>">Dashboard</a></li>
                                    <?php elseif(Auth::user()->role === 'doctor'): ?>
                                        <li class="breadcrumb-item"><a href="<?php echo e(route('doctor.dashboard')); ?>">Dashboard</a></li>
                                    <?php elseif(Auth::user()->role === 'admin'): ?>
                                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                                    <?php endif; ?>
                                    <li class="breadcrumb-item active" aria-current="page">Search a patient</li>
                                </ol>
                            </nav>
                        </div>
                        <div class="nk-block-head-content">
                            
                        </div>
                    </div><!-- .nk-block-head-between -->
                </div><!-- .nk-block-head -->

                <div class="nk-block">
                    <div class="card">
                        



                        
                    </div><!-- .card -->
                </div><!-- .nk-block -->

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/patients/search.blade.php ENDPATH**/ ?>