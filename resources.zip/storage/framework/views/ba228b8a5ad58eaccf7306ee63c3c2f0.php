<?php $__env->startSection('content'); ?>
    <div class="nk-content">
        <div class="container">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    <div class="nk-block-head">
                        <div class="nk-block-head-between flex-wrap gap g-2">
                            <div class="nk-block-head-content">
                                <h2 class="nk-block-title">Users List</h2>
                                <nav>
                                    <ol class="breadcrumb breadcrumb-arrow mb-0">
                                        <li class="breadcrumb-item"><a href="<?php echo e(route('owner.dashboard')); ?>">Dashboard</a></li>
                                        <li class="breadcrumb-item"><a href="<?php echo e(route('owner.employees.manage')); ?>">User Manage</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Users</li>
                                    </ol>
                                </nav>
                            </div>
                            <div class="nk-block-head-content">
                                <ul class="d-flex">
                                    <li>
                                        <a href="#" class="btn btn-primary d-none d-md-inline-flex" data-bs-toggle="modal" data-bs-target="#addUserModal">
                                            <em class="icon ni ni-plus"></em>
                                            <span>Add User</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div><!-- .nk-block-head-between -->
                    </div><!-- .nk-block-head -->

                    <div class="nk-block mb-3">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title g-3 mb-3">Filter Users</h5>
                                <form action="<?php echo e(route('owner.employees.manage')); ?>" method="GET">
                                    <div class="row g-3">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <select class="form-select" id="hospital_id" name="hospital_id">
                                                    <option value="">All Hospitals</option>
                                                    <?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($hospital->id); ?>" <?php echo e(request('hospital_id') == $hospital->id ? 'selected' : ''); ?>>
                                                            <?php echo e($hospital->name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <select class="form-select" id="branch_id" name="branch_id">
                                                    <option value="">All Branches</option>
                                                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($branch->id); ?>" <?php echo e(request('branch_id') == $branch->id ? 'selected' : ''); ?>>
                                                            <?php echo e($branch->name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <select class="form-select" id="role" name="role">
                                                    <option value="">All Roles</option>
                                                    <option value="admin" <?php echo e(request('role') == 'admin' ? 'selected' : ''); ?>>Admin</option>
                                                    <option value="doctor" <?php echo e(request('role') == 'doctor' ? 'selected' : ''); ?>>Doctor</option>
                                                    <option value="lab_technician" <?php echo e(request('role') == 'lab_technician' ? 'selected' : ''); ?>>Lab Technician</option>
                                                    <option value="nurse" <?php echo e(request('role') == 'nurse' ? 'selected' : ''); ?>>Nurse</option>
                                                    <option value="pharmacist" <?php echo e(request('role') == 'pharmacist' ? 'selected' : ''); ?>>Pharmacist</option>
                                                    <option value="receptionist" <?php echo e(request('role') == 'receptionist' ? 'selected' : ''); ?>>Receptionist</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-2 d-grid">
                                            <button type="submit" class="btn btn-soft btn-primary"><span>Filter</span><em class="icon ni ni-arrow-right"></em> </button>
                                        </div>
                                    </div>
                                    <!-- <div class="row g-3 mt-3">
                                        <div class="col-12">
                                            <button type="submit" class="btn btn-primary">Filter</button>
                                            <a href="<?php echo e(route('owner.employees.manage')); ?>" class="btn btn-light">Clear Filters</a>
                                        </div>
                                    </div> -->
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="nk-block">
                        <div class="card">
                            <div class="dataTable-container table-responsive">
                                <table class="datatable-init table dataTable-table" data-nk-container="table-responsive">
                                    <thead class="table-light">
                                        <tr>
                                            <th class="tb-col"><span class="overline-title">Users</span></th>
                                            <th class="tb-col"><span class="overline-title">Role</span></th>
                                            <th class="tb-col"><span class="overline-title">Hospital</span></th>
                                            <th class="tb-col"><span class="overline-title">Branch</span></th>
                                            <th class="tb-col tb-col-xxl"><span class="overline-title">Joined Date</span></th>
                                            <th class="tb-col"><span class="overline-title">Status</span></th>
                                            <th class="tb-col tb-col-end"><span class="overline-title">Action</span></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td class="tb-col">
                                                    <div class="media-group">
                                                        <a href="<?php echo e(route('profile', ['id' => $user->id])); ?>" class="media media-md media-middle media-circle" >
                                                            <div class="media media-md media-middle media-circle" >
                                                                    <img src="<?php echo e(asset('images/users/def.jpg')); ?>" alt="user" onerror="this.src='https://placehold.co/100x100/E9ECEF/000000?text=A'">
                                                            </div>
                                                        </a>
                                                        <div class="media-text">
                                                            <a href="<?php echo e(route('profile', ['id' => $user->id])); ?>" class="title"><?php echo e($user->name); ?></a>
                                                            <span class="small text"><?php echo e($user->email); ?></span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="tb-col"><?php echo e(ucfirst($user->role)); ?></td>
                                                <td class="tb-col">
                                                    <?php if($user->hospital): ?>
                                                        <?php echo e($user->hospital->name); ?>

                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?>
                                                </td>
                                                <td class="tb-col">
                                                    <?php if($user->branch): ?>
                                                        <?php echo e($user->branch->name); ?>

                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?>
                                                </td>
                                                <td class="tb-col tb-col-xxl"><?php echo e($user->created_at->format('Y/m/d')); ?></td>
                                                <td class="tb-col">
                                                    <span class="badge text-bg-success-soft">Active</span>
                                                </td>
                                                <td class="tb-col tb-col-end">
                                                    <div class="dropdown">
                                                        <a href="#" class="btn btn-sm btn-icon btn-zoom me-n1" data-bs-toggle="dropdown">
                                                            <em class="icon ni ni-more-v"></em>
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-sm dropdown-menu-end">
                                                            <div class="dropdown-content py-1">
                                                                <ul class="link-list link-list-hover-bg-primary link-list-md">
                                                                    <li>
                                                                        <a href="#" class="edit-user" data-bs-toggle="modal" data-bs-target="#addUserModal"
                                                                            data-id="<?php echo e($user->id); ?>"
                                                                            data-name="<?php echo e($user->name); ?>"
                                                                            data-email="<?php echo e($user->email); ?>"
                                                                            data-role="<?php echo e($user->role); ?>"
                                                                            data-hospital_id="<?php echo e($user->hospital_id); ?>"
                                                                            data-branch_id="<?php echo e($user->branch_id); ?>">
                                                                            <em class="icon ni ni-edit"></em><span>Edit</span>
                                                                        </a>
                                                                    </li>
                                                                    <li>
                                                                        <form id="delete-form-<?php echo e($user->id); ?>" action="<?php echo e(route('owner.employees.destroy', $user->id)); ?>" method="POST" style="display: none;">
                                                                            <?php echo csrf_field(); ?>
                                                                            <?php echo method_field('DELETE'); ?>
                                                                        </form>
                                                                        <a href="#" onclick="event.preventDefault(); document.getElementById('delete-form-<?php echo e($user->id); ?>').submit();">
                                                                            <em class="icon ni ni-trash"></em><span>Delete</span>
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="7" class="text-center">No users found.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div><!-- .card -->
                    </div><!-- .nk-block -->
                    <?php if($employees->hasPages()): ?>
                        <div class="d-flex justify-content-center mt-4">
                            <?php echo e($employees->links()); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Add/Edit User Modal -->
    <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addUserModalLabel">Add User / Employee</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form id="user-form" action="<?php echo e(route('owner.employees.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input type="hidden" name="_method" id="form-method" value="POST">
                        <div class="row g-3">
                            <div class="col-md-6 mb-0">
                                <label for="first_name" class="form-label">First Name</label>
                                <input type="text" class="form-control" id="first_name" name="first_name" placeholder="Enter first name" required>
                            </div>
                            <div class="col-md-6 mb-0">
                                <label for="last_name" class="form-label">Last Name</label>
                                <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Enter last name" required>
                            </div>
                            <div class="col-md-6 mb-0">
                                <label for="email" class="form-label">Email address</label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="xyz@example.com" required>
                            </div>
                            <div class="col-md-6 mb-0">
                                <label for="phone" class="form-label">Phone Number</label>
                                <input type="text" class="form-control" id="phone" name="phone" placeholder="07XX XXX XXX" required>
                            </div>
                            <div class="col-md-6 mb-0">
                                <label for="role" class="form-label">Role</label>
                                <select class="form-select" id="role" name="role" required>
                                    <option value="">Select user role</option>
                                    <option value="receptionist">Receptionist</option>
                                    <option value="pharmacist">Pharmacist</option>
                                    <option value="lab_technician">Lab Technician</option>
                                    <option value="doctor">Doctor</option>
                                    <option value="nurse">Nurse</option>
                                    <option value="admin">Admin</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-0">
                                <label for="modal_hospital_id" class="form-label">Hospital</label>
                                <select class="form-select" id="modal_hospital_id" name="hospital_id" required>
                                    <option value="">Select a Hospital</option>
                                    <?php $__currentLoopData = $hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($hospital->id); ?>"><?php echo e($hospital->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-0">
                                <label for="modal_branch_id" class="form-label">Branch</label>
                                <select class="form-select" id="modal_branch_id" name="branch_id" required>
                                    <option value="">Select a Branch</option>
                                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($branch->id); ?>"><?php echo e($branch->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-0">
                                <label for="password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="password" name="password" autocomplete="new-password">
                                <!-- <small class="form-text text-muted">Leave blank to keep current password when editing.</small> -->
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" id="modal-submit-btn">Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        // Use a document ready function to ensure the DOM is fully loaded
        $(document).ready(function() {
            // Function to reset the modal form for adding a new user
            $('#addUserModal').on('show.bs.modal', function(event) {
                var button = $(event.relatedTarget);
                var modal = $(this);
                
                // If the "Add User" button is clicked, reset the form.
                if (button.hasClass('btn-primary')) {
                    modal.find('.modal-title').text('Add User');
                    modal.find('#user-form').attr('action', '<?php echo e(route('owner.employees.store')); ?>');
                    modal.find('#form-method').val('POST');
                    modal.find('#first_name').val('');
                    modal.find('#last_name').val('');
                    modal.find('#email').val('');
                    modal.find('#phone').val('');
                    modal.find('#password').prop('required', true).closest('.mb-3').show();
                    modal.find('#modal_hospital_id').val('');
                    modal.find('#modal_branch_id').val('');
                    modal.find('#role').val('doctor');
                    modal.find('#modal-submit-btn').text('Add User');
                }
            });

            // Handle edit button click to populate the modal
            $('.edit-user').on('click', function() {
                var userId = $(this).data('id');
                var userFirstName = $(this).data('first_name');
                var userLastName = $(this).data('last_name');
                var userEmail = $(this).data('email');
                var userPhone = $(this).data('phone');
                var userRole = $(this).data('role');
                var userHospitalId = $(this).data('hospital_id');
                var userBranchId = $(this).data('branch_id');

                var modal = $('#addUserModal');

                // Set modal title and form action for editing
                modal.find('.modal-title').text('Edit User');
                modal.find('#user-form').attr('action', '<?php echo e(url('users')); ?>/' + userId);
                modal.find('#form-method').val('PUT'); // Use PUT for update
                modal.find('#modal-submit-btn').text('Update User');

                // Populate form fields with user data
                modal.find('#first_name').val(userFirstName);
                modal.find('#last_name').val(userLastName);
                modal.find('#email').val(userEmail);
                modal.find('#phone').val(userPhone);
                modal.find('#role').val(userRole);
                modal.find('#modal_hospital_id').val(userHospitalId);
                modal.find('#modal_branch_id').val(userBranchId);

                // Make password field optional for editing
                modal.find('#password').val('').prop('required', false);
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/owner/employees/manage.blade.php ENDPATH**/ ?>