<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Doctor Panel - <?php echo e($patient->first_name); ?> <?php echo e($patient->last_name); ?></h2>

    
    <div class="card mb-3 mt-5">
        <div class="card-header">Prescriptions</div>
        <div class="card-body">
            <form action="<?php echo e(route('doctor.patient.prescriptions.update', $patient->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <textarea name="prescription_notes" class="form-control" rows="3" placeholder="Enter prescription..."></textarea>
                <button type="submit" class="btn btn-primary mt-2">Save Prescription</button>
            </form>

            <ul class="mt-3">
                <?php $__currentLoopData = $patient->prescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($p->notes); ?> (by Dr. <?php echo e($p->doctor->name); ?>)</li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>

    
    <div class="card mb-3">
        <div class="card-header">Lab Tests</div>
        <div class="card-body">
            <form action="<?php echo e(route('doctor.patient.labtests.update', $patient->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="text" name="test_name" class="form-control" placeholder="Enter lab test name">
                <button type="submit" class="btn btn-primary mt-2">Order Lab Test</button>
            </form>

            <ul class="mt-3">
                <?php $__currentLoopData = $patient->labRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($l->test_name); ?> - <strong><?php echo e($l->status); ?></strong></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">Medical Records</div>
        <div class="card-body">
            <form action="<?php echo e(route('doctor.patient.records.update', $patient->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <textarea name="record_notes" class="form-control" rows="3" placeholder="Enter medical notes..."></textarea>
                <button type="submit" class="btn btn-primary mt-2">Save Record</button>
            </form>

            <ul class="mt-3">
                <?php $__currentLoopData = $patient->medicalRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($r->notes); ?> (by Dr. <?php echo e($r->doctor->name); ?>)</li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/doctor/edit.blade.php ENDPATH**/ ?>