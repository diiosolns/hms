<?php $__env->startSection('content'); ?>
    
    <div class="nk-content">
                    <div class="container">
                        <div class="nk-content-inner">
                            <div class="nk-content-body">
                                <div class="nk-block-head">
                                    <div class="nk-block-head-between flex-wrap gap g-2">
                                        <div class="nk-block-head-content">
                                            <h2 class="nk-block-title">Laboratory Tests</h2>
                                                <nav>
                                                    <ol class="breadcrumb breadcrumb-arrow mb-0">
                                                        <?php if(Auth::user()->role === 'receptionist'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('receptionist.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'nurse'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('nurse.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'doctor'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('doctor.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'pharmacist'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('pharmacist.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'lab_technician'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('lab_technician.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'admin'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
                                                        <?php elseif(Auth::user()->role === 'owner'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('owner.dashboard')); ?>">Dashboard</a></li>
                                                        <?php endif; ?>

                                                        <?php if(Auth::user()->role === 'admin'): ?>
                                                        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.lab.create')); ?>">Add new test</a></li>
                                                        <?php endif; ?>
                                                        <li class="breadcrumb-item active" aria-current="page">Manage Lab Tests</li>
                                                    </ol>
                                                </nav>
                                        </div>
                                        <div class="nk-block-head-content">
                                            <ul class="d-flex">
                                                <?php if(Auth::user()->role === 'admin'): ?>
                                                <li>
                                                    <a href="<?php echo e(route('admin.lab.create')); ?>" class="btn btn-md d-md-none btn-primary" >
                                                        <em class="icon ni ni-plus"></em>
                                                        <span>Add</span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="<?php echo e(route('admin.lab.create')); ?>" class="btn btn-primary d-none d-md-inline-flex" >
                                                        <em class="icon ni ni-plus"></em>
                                                        <span>Add Lab Test</span>
                                                    </a>
                                                </li>

                                                <?php elseif(Auth::user()->role === 'receptionist'): ?>

                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div><!-- .nk-block-head-between -->
                                </div><!-- .nk-block-head -->












                                <div class="nk-block">
                                    <div class="card">
                                        <table class="datatable-init table" data-nk-container="table-responsive">
                                            <thead class="table-light">
                                                <tr>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Lab Test</span>
                                                    </th>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Category</span>
                                                    </th>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Sample Type</span>
                                                    </th>
                                                    <th class="tb-col tb-col-xl">
                                                        <span class="overline-title">Normal Range</span>
                                                    </th>
                                                    <th class="tb-col tb-col-md">
                                                        <span class="overline-title">Unit</span>
                                                    </th>
                                                    <th class="tb-col ">
                                                        <span class="overline-title">Price (TZS)</span>
                                                    </th>
                                                    <th class="tb-col">
                                                        <span class="overline-title">Status</span>
                                                    </th>
                                                    <th class="tb-col tb-col-end" data-sortable="false">
                                                        <span class="overline-title">Action</span>
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $labTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td class="tb-col">
                                                        <div class="media-group">
                                                            <div class="media media-md media-middle media-circle text-bg-primary-soft">
                                                                <span class="smaller">
                                                                    <?php echo e(strtoupper(substr($lab->code, 0, 2) )); ?>

                                                                </span>
                                                            </div>
                                                            <div class="media-text">
                                                                <a href="<?php echo e(route('admin.lab.show', $lab->id)); ?>" class="title">
                                                                    <?php echo e($lab->name); ?>

                                                                </a>
                                                                <span class="small text"><?php echo e($lab->code); ?></span>
                                                            </div>
                                                        </div>
                                                    </td>
                                                    <td class="tb-col"><?php echo e($lab->category); ?></td>
                                                    <td class="tb-col"><?php echo e($lab->sample_type); ?></td>
                                                    <td class="tb-col tb-col-xl"><?php echo e($lab->normal_range); ?></td>
                                                    <td class="tb-col tb-col-md"><?php echo e($lab->unit); ?></td>
                                                    <td class="tb-col "><?php echo e($lab->price); ?></td>
                                                    <td class="tb-col">
                                                        <?php if($lab->status === 'Active'): ?>
                                                            <span class="badge text-bg-success-soft"><?php echo e($lab->status); ?></span>
                                                        <?php else: ?>
                                                            <span class="badge text-bg-danger-soft"><?php echo e($lab->status); ?></span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="tb-col tb-col-end">
                                                        <a href="<?php echo e(route('lab_technician.catalog.show', $lab->id)); ?>" class="btn btn-sm btn-outline-primary">
                                                            View
                                                        </a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="6" class="text-center text-muted">No services found.</td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div><!-- .card -->
                                </div><!-- .nk-block -->

                            </div>
                        </div>
                    </div>
                </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/lab_technician/catalog.blade.php ENDPATH**/ ?>