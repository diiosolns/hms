<?php $__env->startSection('content'); ?>
    <div class="nk-content">
        <div class="container">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    
                    <?php if($labRequest): ?>
                        <div class="nk-block-head">
                            <div class="nk-block-head-between flex-wrap gap g-2 align-items-start">
                                <div class="nk-block-head-content">
                                    <div class="d-flex flex-column flex-md-row align-items-md-center">
                                        <!-- <div class="media media-huge media-circle">
                                            
                                            <img src="<?php echo e(asset('images/users/def.jpg')); ?>" class="img-thumbnail" alt="<?php echo e($labRequest->patient->first_name); ?>">
                                        </div> -->
                                        <div class="media media-huge media-middle media-circle text-bg-primary-soft">
                                           <span class="huge"><?php echo e(strtoupper(substr($labRequest->patient->first_name, 0, 1) . substr($labRequest->patient->last_name, 0, 1))); ?></span>
                                        </div>
                                        <div class="mt-3 mt-md-0 ms-md-3">
                                            
                                            <h3 class="title mb-1"><?php echo e($labRequest->patient->first_name); ?> <?php echo e($labRequest->patient->last_name); ?></h3>
                                            
                                            <span class="badge bg-primary">ID: <?php echo e($labRequest->patient->patient_id); ?></span>
                                            <ul class="nk-list-option pt-1">
                                                
                                                <?php if($labRequest->branch): ?>
                                                    <li><em class="icon ni ni-building"></em>
                                                        <span class="small"><?php echo e($labRequest->branch->name); ?></span>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div><!-- .nk-block-head-content -->
                                <div class="nk-block-head-content">
                                    <div class="d-flex gap g-3">
                                        <div class="gap-col">
                                            <a href="<?php echo e(route('lab_technician.patient.back.doctor', $labRequest->patient->id)); ?>" class="btn btn-soft btn-primary">
                                                <em class="icon ni ni-arrow-left"></em>
                                                <span>Back to Doctor</span>
                                            </a>
                                        </div>
                                    </div>
                                </div><!-- .nk-block-head-content -->
                            </div><!-- .nk-block-head-between -->
                        </div><!-- .nk-block-head -->
                        
                        <div class="nk-block">
                            <div class="tab-content" id="myTabContent">




                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul class="mb-0">
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <?php if(session('success')): ?>
                                    <div class="alert alert-success">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>




                                <!-- LABORATORY TAB -->
                                <div class="tab-pane <?php if(Auth::user()->role === 'lab_technician'): ?> show active <?php endif; ?>  " id="pills-lab" role="lab">
                                    <?php $__empty_1 = true; $__currentLoopData = $labRequest->requestTests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="card h-100 mt-3">
                                                <div class="col-sep">
                                                    <div class="card-body py-2">
                                                        <div class="card-title-group">
                                                            <div class="card-title">
                                                                <h4 class="title mb-0"><?php echo e($test->labTest->name); ?></h4>
                                                            </div>
                                                            <div class="card-tools">
                                                                <?php if($test->status !== 'Cancelled' && in_array(Auth::user()->role, [ 'admin', 'lab_technician'])): ?>
                                                                <a href="" class="btn btn-sm btn-soft btn-primary"  class="btn btn-soft btn-primary" data-bs-toggle="modal" data-bs-target="#updateTestResultsModal<?php echo e($test->status); ?>" >
                                                                    <em class="icon ni ni-edit"></em> <span>Update Results</span>
                                                                </a>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div><!-- .card-title-group -->
                                                    </div><!-- .card-body -->
                                                    <div class="card-body">
                                                        <div class="nk-timeline nk-timeline-center">
                                                            <ul class="nk-timeline-list">
                                                                <li class="nk-timeline-item">
                                                                    <div class="nk-timeline-item-inner">
                                                                        <div class="nk-timeline-symbol">
                                                                            <div class="media media-md media-middle media-circle">
                                                                                <img src="<?php echo e(asset('images/users/def.jpg')); ?>" alt="">
                                                                            </div>
                                                                        </div>
                                                                        <div class="nk-timeline-content">
                                                                            <p class="small"><strong>Test Results</strong> </p>
                                                                            <span class="smaller time">Unit: <?php echo e($test->unit ?? 'None'); ?> | <?php echo e($test->reference_range ?? ''); ?></span>
                                                                            <p class="small"><?php echo e($test->result ?? 'No results yet.'); ?></p>
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                                <li class="nk-timeline-item">
                                                                    <div class="nk-timeline-item-inner">
                                                                        <div class="nk-timeline-symbol">
                                                                            <div class="media media-md media-middle media-circle">
                                                                                <img src="<?php echo e(asset('images/users/def.jpg')); ?>" alt="">
                                                                            </div>
                                                                        </div>
                                                                        <div class="nk-timeline-content">
                                                                            <p class="small"><strong>Attachment</strong></p>
                                                                            <!-- <span class="smaller time">pdf/ Image file </span> -->
                                                                            <?php if($test->attachment): ?>
                                                                                <a href="<?php echo e(asset('storage/' . $test->attachment)); ?>" target="_blank" class="btn btn-sm btn-primary">
                                                                                    <em class="icon ni ni-eye"></em> Preview
                                                                                </a>

                                                                                <a href="<?php echo e(asset('storage/' . $test->attachment)); ?>" download class="btn btn-sm btn-secondary">
                                                                                    <em class="icon ni ni-download"></em> Download
                                                                                </a>
                                                                            <?php else: ?>
                                                                                <p class="small">No attachment yet.</p>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                            </ul>
                                                        </div><!-- .nk-timeline -->
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- UPDATE RESULTS MODAL -->
                                            <div class="modal fade" id="updateTestResultsModal<?php echo e($test->status); ?>" tabindex="-1" aria-labelledby="updateTestResultsModalLabel<?php echo e($test->status); ?>" aria-hidden="true">
                                                <div class="modal-dialog modal-md">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="updateNurseTriageModalLabel"><?php echo e($test->labTest->name); ?></h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <form action="<?php echo e(route('lab_technician.results.upload', $test->id)); ?>" method="POST" enctype="multipart/form-data">
                                                            <?php echo csrf_field(); ?>
                                                           <div class="modal-body">
                                                                <div class="row g-3 gx-gs">
                                                                    <div class="col-md-12">
                                                                        <div class="form-group">
                                                                            <label for="result" class="form-label">Test Results</label>
                                                                            <div class="form-control-wrap">
                                                                                <textarea name="result" placeholder="Enter test resul description" class="form-control" id="result" rows="3"><?php echo e($test->result ?? ''); ?></textarea>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-12">   
                                                                        <div class="form-group">
                                                                            <label for="attachment" class="form-label">Attachment</label>
                                                                            <div class="form-control-wrap">
                                                                                <input 
                                                                                    name="attachment" 
                                                                                    class="form-control" 
                                                                                    type="file" 
                                                                                    id="attachment" 
                                                                                    accept=".pdf,.jpg,.jpeg,.png"
                                                                                />
                                                                                <small class="text-muted text-primary">Allowed file types: PDF, JPG, JPEG, PNG</small>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <input type="hidden" name="status" value="Closed">
                                                                <button type="submit" class="btn btn-md btn-primary">Update Results</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- END UPDATE RESULTS MODAL -->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                          <div>
                                              <p>No lab tests requested.</p>
                                          </div>
                                        <?php endif; ?>

                                </div><!-- .lab tab-pane -->



                            </div><!-- .tab-content -->
                        </div><!-- .nk-block -->
                    <?php else: ?>
                        
                        <div class="alert alert-danger" role="alert">
                            labRequest not found.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>









<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hms\resources\views/lab_technician/tests.blade.php ENDPATH**/ ?>