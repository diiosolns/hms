<li class="nk-menu-item">
    <a href="<?php echo e(route('receptionist.dashboard')); ?>" class="nk-menu-link">
        <span class="nk-menu-icon"><em class="icon ni ni-dashboard"></em></span>
        <span class="nk-menu-text">Dashboard</span>
    </a>
</li>

<li class="nk-menu-heading">
    <h6 class="overline-title">Operations</h6>
</li>

<li class="nk-menu-item has-sub">
    <a href="#" class="nk-menu-link nk-menu-toggle">
        <span class="nk-menu-icon"><em class="icon ni ni-user-add"></em></span>
        <span class="nk-menu-text">Patient</span>
    </a>
    <ul class="nk-menu-sub">
        <li class="nk-menu-item"><a href="<?php echo e(route('patients.create')); ?>" class="nk-menu-link"><span class="nk-menu-text">Register New Patient</span></a></li>
        <li class="nk-menu-item"><a href="<?php echo e(route('patients.index')); ?>" class="nk-menu-link"><span class="nk-menu-text">Patient List</span></a></li>
    </ul>
</li>

<li class="nk-menu-item has-sub">
    <a href="#" class="nk-menu-link nk-menu-toggle">
        <span class="nk-menu-icon"><em class="icon ni ni-calendar-alt"></em></span>
        <span class="nk-menu-text">Appointments</span>
    </a>
    <ul class="nk-menu-sub">
        <li class="nk-menu-item"><a href="<?php echo e(route('appointments.create')); ?>" class="nk-menu-link"><span class="nk-menu-text">Schedule Appointment</span></a></li>
        <li class="nk-menu-item"><a href="<?php echo e(route('appointments.index')); ?>" class="nk-menu-link"><span class="nk-menu-text">All Appointments</span></a></li>
    </ul>
</li>

<li class="nk-menu-item">
    <a href="<?php echo e(route('billing.create')); ?>" class="nk-menu-link">
        <span class="nk-menu-icon"><em class="icon ni ni-cc-alt2"></em></span>
        <span class="nk-menu-text">Billing</span>
    </a>
</li>


<li class="nk-menu-item">
    <a href="<?php echo e(route('logout')); ?>" class="nk-menu-link" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        <span class="nk-menu-icon"><em class="icon ni ni-signout"></em></span>
        <span class="nk-menu-text">Logout</span>
    </a>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>
</li><?php /**PATH C:\xampp\htdocs\hms\resources\views/layouts/menu/receptionist-menu.blade.php ENDPATH**/ ?>