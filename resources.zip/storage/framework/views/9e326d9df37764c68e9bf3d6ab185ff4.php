<!DOCTYPE html>
<html lang="en">

<head>
    <base href="/">
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Multi-purpose admin dashboard template that especially build for programmers.">
    <title>HMS</title>
    <link rel="shortcut icon" href="<?php echo e(asset('images/app/favicon.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css?v1.1.1')); ?>">
</head>

<body class="nk-body" data-sidebar-collapse="lg" data-navbar-collapse="lg">
    <!-- Root  -->
    <div class="nk-app-root">
        <!-- main  -->
        <?php echo $__env->yieldContent('content'); ?>
    </div> <!-- .nk-app-root -->
</body>
<!-- JavaScript -->
<script src=".<?php echo e(asset('assets/js/bundle.js')); ?>"></script>
<script src=".<?php echo e(asset('assets/js/scripts.js')); ?>"></script>

</html><?php /**PATH C:\xampp\htdocs\hms\resources\views/layouts/err.blade.php ENDPATH**/ ?>